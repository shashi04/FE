import React, { FunctionComponent, useEffect } from "react";
import Navbar from "../Components/Navbar/Navbar";
import { Route } from "react-router-dom";

import DrilldownPanel from "../Screens/UserPanel/DrillDownPanel";
import DrilldownTaskPanel from "../Screens/TasksPanel/DrilldownTaskPanel";
import DrilldownCallLogsPanel from "../Screens/CallLogsPanel/DrilldownCallLogsPanel";

type props = {
  user: any;
  history: any;
  leadsStage: any;
};

const DrilldownDataRoute: FunctionComponent<props> = ({
  history,
  user,
  leadsStage,
}) => {
  return (
    <>
      <Navbar
        props={{ history }}
        title={"Drilldown"}
        path={"/drilldownData"}
        leadManger={true}
        project={"/projects"}
        task={"/tasks"}
        resources={"/resources"}
        callLogs={"/callLogs"}
        faq={"/faq"}
      />
      <Route path="/drilldownData" component={DrilldownPanel} />
      <Route path="/taskDrilldownData" component={DrilldownTaskPanel} />
      <Route path="/callDrilldownData" component={DrilldownCallLogsPanel} />
    </>
  );
};

export default DrilldownDataRoute;
