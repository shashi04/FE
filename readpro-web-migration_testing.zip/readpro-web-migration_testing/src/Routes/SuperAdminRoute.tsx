import React from "react";
import Navbar from "../Components/Navbar/Navbar";
import Analytics from "../Screens/Analytics/Analytics";
import SuperAdminPanel from "../Screens/SuperAdminPanel/SuperAdminPanel";
import Reports from "../Screens/Reports/Reports";
import AddOrganization from "../Screens/AddOrganization/AddOrganization";
import { Route } from "react-router-dom";
import EditOrganization from "../Screens/EditOrganization/EditOrganization";
import styles from '../Screens/Analytics/Analytics.module.css'
import AnalyticsSideNav from "../Components/AnalyticsSideNav/AnalyticsSideNav";

const SuperAdminRoute = (props: any) => {
  return (
    <>
      <Navbar
        props={props}
        title={"Organizations"}
        path={"/"}
        leadManger={false}
      />
       <div className={styles.parent}>
        <AnalyticsSideNav
          props={props}
          title={"Organizations"}
          path={"/"}
          leadManger={false}
        />
       <Route exact path="/" component={SuperAdminPanel} />
      {/* <Route path="/analytics" component={Analytics} />
      <Route path="/reports" component={Reports} /> */}
      <Route path="/addOrganizations" component={AddOrganization} />
      <Route path="/editOrganizations" component={EditOrganization} />
      </div>
      
    </>
  );
};

export default SuperAdminRoute;
