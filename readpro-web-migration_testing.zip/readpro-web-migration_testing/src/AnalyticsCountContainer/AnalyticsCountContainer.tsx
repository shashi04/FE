import React, { FunctionComponent, useState } from "react";
import styles from "../CommonStyles/CommonGraphStyles.module.css";
import CountBox from "../Components/CountBox/CountBox";

type props = {
  stage: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  taskStage: any;
  taskFilter?: any;
  leadFilter?: any;
  otherTaskFilter?: any;
  otherContactFilter?: any;
  source:any;
  total:any;
};

const AnalyticsCountContainer: FunctionComponent<props> = ({
  stage,
  history,
  filter,
  taskStage,
  taskFilter,
  leadFilter,
  otherTaskFilter,
  otherContactFilter,
  source,
  total

}) => {
 
  return (
    <>
    <CountBox
        count={total}
        text="Total Leads"
        style={{ color: "rgb(213, 30, 30)"}}
        history={history}
        filterText=""
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />
      <CountBox
        count={stage.FRESH}
        text="Fresh"
        style={{ color:"rgba(255, 99, 132, 1)"}}
        history={history}
        filterText="FRESH"
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />
      <CountBox
        count={stage.CALLBACK}
        text="Call Back"
        style={{ color:"rgba(54, 162, 235, 1)"}}
        history={history}
        filterText="CALLBACK"
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />
      <CountBox
        count={stage.INTERESTED}
        text="Interested"
        style={{ color:"rgba(255, 206, 86, 1)"}}
        history={history}
        filterText="INTERESTED"
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />
      <CountBox
        count={stage.WON}
        text="Closed Won"
        style={{ color:"rgba(75, 192, 192, 1)"}}
        history={history}
        filterText="WON"
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />
      <CountBox
        count={stage["NOT INTERESTED"]}
        text="Not Interested"
        style={{ color:"rgba(153, 102, 255, 1)"}}
        history={history}
        filterText="NOT INTERESTED"
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />
      <CountBox
        count={stage.LOST}
        text="Closed Lost"
        style={{ color:"rgba(255, 159, 64, 1)"}}
        history={history}
        filterText="LOST"
        filter={filter}
        taskFilter={taskFilter}
        leadFilter={leadFilter}
        source={source}
      />

      <CountBox
        count={taskStage["Completed"]}
        text="Completed Visits"
        style={{ color:"#00008b"}}
        history={history}
        filterText="Completed"
        filter={filter}
        taskFilter={otherTaskFilter}
        leadFilter={otherContactFilter}
        source={source}
      />
      <CountBox
        count={taskStage["Pending"]}
        text="Scheduled Visits"
        style={{ color:"#2FA2D3"}}
        history={history}
        filterText="Pending"
        filter={filter}
        taskFilter={otherTaskFilter}
        leadFilter={otherContactFilter}
        source={source}
      />
    </>
  );
};

export default AnalyticsCountContainer;
