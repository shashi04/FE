import React, { FunctionComponent, useState, useRef, useEffect } from "react";
import styles from "./DeleteSelectedModal.module.css";
import Modal from "react-modal";
import { connect, useDispatch } from "react-redux";
import Loading from "../../Loading/Loading";
import { deleteProject, fetchProjects } from "../../../Services/contacts";
import { showSnackbarAction } from "../../../Redux/actions";
import { db, firestore, functions, storage } from "../../../Firebase";
import Firebase from "firebase/app";
import { deleteRecords } from "../../../Services/contacts";
import axios from "axios";

import { url } from "../../../Values/constants";


type props = {
    open: boolean;
    close: () => void;
    data: any;
    totalData: any;
    organization_id: any;
    clearSelectedRowsData?: () => void;
};

const DeleteProjectSelectedModal: FunctionComponent<props> = ({
    open,
    close,
    clearSelectedRowsData,
    data,
    totalData,
    organization_id
}) => {


    const [load, setLoad] = useState(false);
    const dispatcher = useDispatch();
    const deleteProjectFirebase = () => {
        if (data) {
            setLoad(true);
            let newIndex: number;
            let finalIndex = [];
            for (let item of data) {
                newIndex = totalData.findIndex((i: { project_name: any; }) => i.project_name === item.project_name);
                finalIndex.push(newIndex);
            }
            finalIndex.sort();
            console.log("New index numbers:", finalIndex);
            // for (let item of data) {
            deleteProject(
                // item.project_name,
                organization_id,
                totalData,
                finalIndex,
                dispatcher,
                (item) => setLoad(item)
            );
            // }


        }
        setTimeout(() => {
            close();
            setLoad(false);
            dispatcher(showSnackbarAction("Record Delted", "success"));
            clearSelectedRowsData && clearSelectedRowsData();
            window.location.reload();
        }, 2500);
    };
    return (
        <>
            <Modal
                isOpen={open}
                className={styles.parent}
                overlayClassName={styles.overlay}
                onRequestClose={close}
                shouldCloseOnOverlayClick={true}
                shouldCloseOnEsc={true}
            >
                {load && <Loading />}
                <div className={styles.headingContainer}>
                    <p className={styles.heading}>Delete Selected Records</p>
                </div>
                <div className={styles.container}>
                    <div className={styles.subheading}>
                        <p className={styles.optionHeading}>Selected Options</p>
                    </div>
                    <ol>
                        {data.map((dat: any) => (
                            <li>{dat.project_name}</li>
                        ))}
                    </ol>
                </div>

                <div className={styles.buttonView}>
                    <button className={styles.cancelButton} onClick={close}>
                        Cancel
                    </button>
                    <button className={styles.saveButton} onClick={deleteProjectFirebase}>
                        Delete
                    </button>
                </div>
            </Modal>
        </>
    );
};
export default DeleteProjectSelectedModal;
