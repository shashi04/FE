import React, {
  FunctionComponent,
  useEffect,
  useState,
  useRef,
} from "react";
import styles from "../BulkEditModal/BulkEditModal.module.css";
import Modal from "react-modal";
import { IoIosClose } from "react-icons/io";

import Dropdown from "../../DropDown/Dropdown";
import {
  addNoteFirebase,
  changeLeadStage,
  fetchConstants,
} from "../../../Services/contacts";

import Loading from "../../Loading/Loading";
import { connect, useDispatch } from "react-redux";
import { showSnackbarAction } from "../../../Redux/actions";
import { useHistory } from "react-router-dom";
import TextInput from "../../TextInput/TextInput";

type props = {
  contactDetail: any;
  close: () => void;
  open: boolean;
  tasksData: any[];
  notes: any[];
  user: any;
};

const LostModal: FunctionComponent<props> = ({
  contactDetail,
  close,
  open,
  tasksData,
  notes,
  user,
}) => {
  const otherRef: any = useRef();
  const noteRef: any = useRef();
  const [load, setLoad] = useState(false);
  const [lostSelected, setLostSelected] = useState<any>({
    label: contactDetail.lost_reason
      ? contactDetail.lost_reason
      : "Select",
    value: contactDetail.lost_reason
      ? contactDetail.lost_reason
      : "Select",
  });

  const [propertyTypeList, setPropertyTypeList] = useState<
    any[]
  >([]);
  const [propertyStageList, setPropertyStageList] =
    useState<any[]>([]);
  const [nextFollowUpList, setnextFollowUpList] = useState<
    any[]
  >([]);
  const [notIntReasonList, setNotIntReasonList] = useState<
    any[]
  >([]);
  const [lostReasonList, setLostReasonList] = useState<
    any[]
  >([]);
  const [other, setOther] = useState("");

  useEffect(() => {
    const unsubConst = fetchConstants(
      (data) => setNotIntReasonList(data),
      (data) => setLostReasonList(data),
      (data) => setPropertyStageList(data),
      (data) => setPropertyTypeList(data),
      (data) => setnextFollowUpList(data)
    );

    return () => {
      unsubConst();
    };
    // eslint-disable-next-line
  }, []);

  const dispatcher = useDispatch();
  const history = useHistory();
  const onSubmit = () => {
    if (lostSelected.value === "Select") {
      dispatcher(
        showSnackbarAction(
          "Please Select Lost Reason",
          "error"
        )
      );
    } else if (
      lostSelected.value === "Other" &&
      other === ""
    ) {
      dispatcher(
        showSnackbarAction(
          "Please Mention Other Lost Reason",
          "error"
        )
      );
    } else {
      if (noteRef.current.value.length !== 0) {
        addNoteFirebase(
          contactDetail.contactId,
          notes,
          noteRef.current.value,
          () => {},
          dispatcher,
          () => {},
          user.user_email
        );
      }
      changeLeadStage(
        contactDetail.contactId,
        {
          lost_reason: lostSelected.value,
          stage: "LOST",
          other_lost_reason: other === "" ? "" : other,
        },
        (data) => setLoad(data),
        dispatcher,
        close,
        history,
        tasksData
      );
    }
  };
  return (
    <Modal
      className={styles.parent}
      isOpen={open}
      shouldCloseOnOverlayClick={true}
      overlayClassName={styles.overlay}
      shouldCloseOnEsc={true}
      onRequestClose={close}
    >
      {load === true && <Loading />}
      <div className={styles.firstDiv}>
        <p className={styles.contactForm}>Lost Details</p>
        <div className={styles.cross} onClick={close}>
          <IoIosClose size={35} color={"#808080"} />
        </div>
      </div>
      <div className={styles.line}></div>

      <div className={styles.box2}>
        <div
          className={styles.divide}
          style={{ width: "100%" }}
        >
          <div className={styles.title}>
            <p className={styles.one}>Lost Reason</p>
            <p className={styles.two}></p>
          </div>
          <div style={{ marginTop: "7px" }}>
            <Dropdown
              option={lostReasonList}
              selectedValue={lostSelected}
              setSelectedValue={(value) => {
                setLostSelected(value);
              }}
            />
          </div>
        </div>
      </div>

      {lostSelected.value === "Other" && (
        <div className={styles.box2}>
          <div
            className={styles.divide}
            style={{ width: "100%" }}
          >
            <div className={styles.title}>
              <p className={styles.one}>
                Other Lost Reason
              </p>
              <p className={styles.two}></p>
            </div>
            <textarea
              style={{
                width: "100%",
                resize: "none",
                marginTop: "17px",
              }}
              rows={4}
              cols={10}
              placeholder={"Enter Other Reason"}
              ref={otherRef}
              onChange={(e) => setOther(e.target.value)}
              value={other}
            ></textarea>
          </div>
        </div>
      )}

      <div className={styles.box2}>
        <div
          className={styles.divide}
          style={{ width: "100%" }}
        >
          <div className={styles.title}>
            <p className={styles.one}>Note</p>
            <p className={styles.two}></p>
          </div>
          <div>
            <TextInput
              title={"Enter Note"}
              style={{ backgroundColor: "#fff" }}
              ref={noteRef}
            ></TextInput>
          </div>
        </div>
      </div>

      <button
        className={styles.apply}
        style={{ marginTop: "auto" }}
        onClick={onSubmit}
      >
        Save
      </button>
    </Modal>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
  };
};

export default connect(mapStateToProps)(LostModal);
