import React, { FunctionComponent, useState, useRef } from "react";
import styles from "./ChangeStageModal.module.css";
import Modal from "react-modal";
import { connect, useDispatch } from "react-redux";

import Loading from "../../Loading/Loading";
import Dropdown from "../../DropDown/Dropdown";
import { useEffect } from "react";
import {
  changeLeadsStage,
  fetchOrganizationLeadPermission,
  setLeadPermission,
} from "../../../Services/organizations";
import { showSnackbarAction } from "../../../Redux/actions";
import { changeLeadStage } from "../../../Services/contacts";

type props = {
  open: boolean;
  close: () => void;
};
const ChangeStageModal: FunctionComponent<props> = ({ open, close }) => {
  const leadsRef: any = useRef();
  const dispatcher = useDispatch();
  const [load, setLoad] = useState(false);
  const [leads, setLeads] = useState("");

  const onSave = () => {
    if (leads === "") {
      dispatcher(showSnackbarAction("Please Enter Lead Ids", "error"));
    } else {
      setLoad(true);
      changeLeadsStage(leads.split(","), dispatcher, (data) => setLoad(data));
    }
  };

  return (
    <Modal
      isOpen={open}
      className={styles.parent}
      overlayClassName={styles.overlay}
      onRequestClose={close}
      shouldCloseOnOverlayClick={true}
      shouldCloseOnEsc={true}
    >
      {load && <Loading />}
      <div className={styles.headingContainer}>
        <p className={styles.heading}>Change Stage</p>
      </div>

      <textarea
        style={{ width: "90%", resize: "none", marginTop: "57px" }}
        rows={4}
        cols={10}
        placeholder={"Enter Lead Ids"}
        ref={leadsRef}
        onChange={(e) => setLeads(e.target.value)}
        value={leads}
      ></textarea>
      <div className={styles.buttonView}>
        <button className={styles.cancelButton} onClick={close}>
          Cancel
        </button>
        <button className={styles.saveButton} onClick={() => onSave()}>
          Save
        </button>
      </div>
    </Modal>
  );
};

const mapStateToProps = (state: any) => {
  return {
    organizationId: state.organization.id,
    organizationUsers: state.organizationUsers.data,
  };
};

export default connect(mapStateToProps)(ChangeStageModal);
