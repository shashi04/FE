import React, { FunctionComponent, useState, useRef, useEffect } from "react";
import styles from "../ListViewModal/ListViewModal.module.css";
import Modal from "react-modal";
import { connect, useDispatch } from "react-redux";

import Loading from "../../Loading/Loading";

import { createApi, editApi } from "../../../Services/organizations";
import { showSnackbarAction } from "../../../Redux/actions";
import TextInput from "../../TextInput/TextInput";

type props = {
  open: boolean;
  close: () => void;
  organizationId: any;
  organizationUsers: any;
  edit?: boolean;
  editData?: any;
  editClose?: () => void;
};

const ApiModal: FunctionComponent<props> = ({
  organizationId,
  open,
  close,
  edit,
  editData,
  editClose,
}) => {
  const sourceRef: any = useRef();
  const countryRef: any = useRef();
  const [load, setLoad] = useState(false);
  const [source, setSource] = useState();
  const [countryCode, setCountryCode] = useState();
  const dispatcher = useDispatch();
  const onSave = () => {
    if (sourceRef.current.value === "") {
      dispatcher(showSnackbarAction("Please Enter Source!!", "error"));
    } else {
      setLoad(true);

      createApi(
        organizationId,
        sourceRef.current.value,
        countryRef.current.value === ""
          ? ""
          : countryRef.current.value.startsWith("+")
          ? countryRef.current.value
          : "+" + countryRef.current.value,
        dispatcher,
        (val) => setLoad(val),
        close
      );
    }
  };

  useEffect(() => {
    console.log(editData);
  }, []);

  const onEdit = () => {
    if (sourceRef.current.value === "") {
      dispatcher(showSnackbarAction("Please Enter Source!!", "error"));
    } else {
      if (editClose) {
        setLoad(true);
        editApi(
          sourceRef.current.value,
          countryRef.current.value === ""
            ? ""
            : countryRef.current.value.startsWith("+")
            ? countryRef.current.value
            : "+" + countryRef.current.value,
          editData.api_key,
          dispatcher,
          (data) => setLoad(data),
          close,
          editClose
        );
      }
    }
  };

  useEffect(() => {
    if (edit) {
      setSource(editData.source);
      setCountryCode(editData.country_code);
    }
  }, []);
  return (
    <Modal
      isOpen={open}
      className={styles.parent}
      overlayClassName={styles.overlay}
      onRequestClose={close}
      shouldCloseOnOverlayClick={true}
      shouldCloseOnEsc={true}
    >
      {load && <Loading />}
      <div className={styles.headingContainer}>
        <p className={styles.heading}>Create API</p>
      </div>
      <div className={styles.profileContainer}>
        <p className={styles.profile}>Enter Source</p>
        <TextInput
          title={"Enter Source"}
          ref={sourceRef}
          disabled={false}
          value={source}
          style={{ marginTop: "-0.5px" }}
        />
      </div>

      <div className={styles.profileContainer}>
        <p className={styles.profile} style={{ marginTop: "20px" }}>
          Enter Country Code
        </p>
        <TextInput
          title={"Enter Country Code"}
          ref={countryRef}
          disabled={false}
          style={{ marginTop: "-0.5px" }}
        />
      </div>

      <div className={styles.buttonView}>
        <button
          className={styles.cancelButton}
          onClick={() => {
            close();
            editClose && editClose();
          }}
        >
          Cancel
        </button>
        {edit === true ? (
          <button className={styles.saveButton} onClick={() => onEdit()}>
            Edit
          </button>
        ) : (
          <button className={styles.saveButton} onClick={() => onSave()}>
            Save
          </button>
        )}
      </div>
    </Modal>
  );
};

const mapStateToProps = (state: any) => {
  return {
    organizationId: state.organization.id,
    organizationUsers: state.organizationUsers.data,
  };
};

export default connect(mapStateToProps)(ApiModal);
