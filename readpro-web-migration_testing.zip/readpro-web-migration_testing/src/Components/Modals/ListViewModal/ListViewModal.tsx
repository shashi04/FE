import React, { FunctionComponent, useState } from "react";
import styles from "./ListViewModal.module.css";
import Modal from "react-modal";
import { connect, useDispatch } from "react-redux";

import Loading from "../../Loading/Loading";
import Dropdown from "../../DropDown/Dropdown";
import { useEffect } from "react";
import {
  fetchOrganizationLeadPermission,
  setLeadPermission,
} from "../../../Services/organizations";
import { showSnackbarAction } from "../../../Redux/actions";

type props = {
  open: boolean;
  close: () => void;
  organizationId: any;
  organizationUsers: any[];
};
const ListVieweModal: FunctionComponent<props> = ({
  open,
  close,
  organizationId,
  organizationUsers,
}) => {
  const dispatcher = useDispatch();
  const [load, setLoad] = useState(false);
  const [profileSelected, setProfileSelected] = useState<any>({
    label: "Select",
    value: "Select",
  });
  const [optionsSelected, setOptionsSelected] = useState<any[]>([]);
  const [permissions, setPermissions] = useState<any>();

  useEffect(() => {
    if (organizationId) {
      fetchOrganizationLeadPermission(organizationId, (val) =>
        setPermissions(val)
      );
    }
  }, [organizationId]);

  useEffect(() => {
    if (permissions) {
      let data = [];
      if (permissions[profileSelected.value] === undefined) {
        setOptionsSelected([]);
      } else {
        data = permissions[profileSelected.value];

        setOptionsSelected(data);
      }
    }
  }, [profileSelected.value]);

  const onCheck = (event: any, value: string) => {
    if (event.target.checked) {
      let data = [...optionsSelected];
      data.push(value);
      setOptionsSelected(data);
    } else if (!event.target.checked) {
      let data = [...optionsSelected];
      let item = optionsSelected.indexOf(value);
      if (item > -1) {
        data.splice(item, 1);
      }
      setOptionsSelected(data);
    }
  };

  const onSave = () => {
    let check = false;
    if (profileSelected.value === "" || profileSelected.value === "Select") {
      dispatcher(showSnackbarAction("Please Select Profile", "error"));
    } else {
      check = true;
    }
    if (check === true && organizationUsers) {
      setLoad(true);
      setLeadPermission(
        organizationId,
        profileSelected.value,
        optionsSelected,
        dispatcher,
        (val) => setLoad(val),
        close,
        organizationUsers
      );
    }
  };

  return (
    <Modal
      isOpen={open}
      className={styles.parent}
      overlayClassName={styles.overlay}
      onRequestClose={close}
      shouldCloseOnOverlayClick={true}
      shouldCloseOnEsc={true}
    >
      {load && <Loading />}
      <div className={styles.headingContainer}>
        <p className={styles.heading}>Set List View</p>
      </div>
      <div className={styles.profileContainer}>
        <p className={styles.profile}>Select Profile</p>
        <Dropdown
          option={["Team Lead", "Sales"]}
          selectedValue={profileSelected}
          setSelectedValue={(value) => setProfileSelected(value)}
        />
      </div>
      <div className={styles.box}>
        <div className={styles.first}>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Budget");
              }}
              checked={optionsSelected.includes("Budget")}
            />
            <p className={styles.option}>Budget</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Contact No.");
              }}
              checked={optionsSelected.includes("Contact No.")}
            />
            <p className={styles.option}>Contact No.</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Created At");
              }}
              checked={optionsSelected.includes("Created At")}
            />
            <p className={styles.option}>Created At</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Created By");
              }}
              checked={optionsSelected.includes("Created By")}
            />
            <p className={styles.option}>Created By</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Customer Name");
              }}
              checked={optionsSelected.includes("Customer Name")}
            />
            <p className={styles.option}>Customer Name</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Email");
              }}
              checked={optionsSelected.includes("Email")}
            />
            <p className={styles.option}>Email</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Source");
              }}
              checked={optionsSelected.includes("Source")}
            />
            <p className={styles.option}>Source</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Assign Time");
              }}
              checked={optionsSelected.includes("Assign Time")}
            />
            <p className={styles.option}>Assign Time</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Addset");
              }}
              checked={optionsSelected.includes("Addset")}
            />
            <p className={styles.option}>Addset</p>
          </div>
        </div>

        <div className={styles.first}>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Location");
              }}
              checked={optionsSelected.includes("Location")}
            />
            <p className={styles.option}>Location</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Project");
              }}
              checked={optionsSelected.includes("Project")}
            />
            <p className={styles.option}>Project</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Property Stage");
              }}
              checked={optionsSelected.includes("Property Stage")}
            />
            <p className={styles.option}>Property Stage</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Property Type");
              }}
              checked={optionsSelected.includes("Property Type")}
            />
            <p className={styles.option}>Property Type</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Follow Up Type");
              }}
              checked={optionsSelected.includes("Follow Up Type")}
            />
            <p className={styles.option}>Follow Up Type</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Follow Up Date Time");
              }}
              checked={optionsSelected.includes("Follow Up Date Time")}
            />
            <p className={styles.option}>Follow Up Date Time</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Owner");
              }}
              checked={optionsSelected.includes("Owner")}
            />
            <p className={styles.option}>Owner</p>
          </div>
          <div className={styles.detail}>
            <input
              type="checkbox"
              onChange={(e) => {
                onCheck(e, "Campaign");
              }}
              checked={optionsSelected.includes("Campaign")}
            />
            <p className={styles.option}>Campaign</p>
          </div>
        </div>
      </div>
      <div className={styles.buttonView}>
        <button className={styles.cancelButton} onClick={close}>
          Cancel
        </button>
        <button className={styles.saveButton} onClick={() => onSave()}>
          Save
        </button>
      </div>
    </Modal>
  );
};

const mapStateToProps = (state: any) => {
  return {
    organizationId: state.organization.id,
    organizationUsers: state.organizationUsers.data,
  };
};

export default connect(mapStateToProps)(ListVieweModal);
