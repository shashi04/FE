import React, { useState } from "react";
import styles from "./PasswordInput.module.css";
import { BsEyeFill,BsEyeSlashFill } from "react-icons/bs";

type props = {
  title: string;
  children?: any;
  validator?: (value: string) => string;
  onPress?: () => void;
};

const PasswordInput = React.forwardRef(
  ({ title, children, validator, onPress }: props, ref: any) => {
    const [show, setShow] = useState(false);
    const [errorMsg, setErrorMsg] = useState("");
    return (
      <>
        <div className={styles.input}>
          {children}
          <input
            id={styles.inputText}
            type={show ? "text" : "password"}
            name="name"
            placeholder={title}
            ref={ref}
            onBlur={() => {
              if (validator) {
                setErrorMsg(validator(ref.current.value));
              }
            }}
            onKeyDown={(e) => {
              if (onPress) {
                if (e.code === "Enter") {
                  onPress();
                }
              }
            }}
          />
          <div className={styles.try}>
           { show ? <BsEyeFill color={"#808080"} onClick={() => setShow(!show)} />: <BsEyeSlashFill color={"#808080"} onClick={() => setShow(!show)} />}

            
          </div>
        </div>
        {errorMsg.length !== 0 && <p className={styles.error}>{errorMsg}</p>}
      </>
    );
  }
);

export default PasswordInput;
