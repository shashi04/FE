import React, { FunctionComponent, useEffect, useState } from "react";
import ReactEcharts from "echarts-for-react";
import { properFormat } from "../../Values/utils";

type props = {
    chartData: any;
};
const BarChart: FunctionComponent<props> = ({ chartData }) => {
    const [arrchartData, setArrChartData] = useState<any[]>([]);

    useEffect(() => {
        let arrChartData = [];
        for (const [key, value] of Object.entries(chartData)) {
            arrChartData.push({ value: value, name: properFormat(key) },)
        }
        setArrChartData(arrChartData);
    }, [chartData])
    
    const getOption = () => ({
        // title: {
        //   text: "折线图堆叠"
        // },
        tooltip: {
            trigger: "axis"
        },
        legend: {
            data: Object.keys(chartData).map((item) => properFormat(item))
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: "category",
            data: Object.keys(chartData).map((item) => properFormat(item))
        },
        yAxis: {
            type: "value"
        },
        series: [
            {
                type: "bar",
                data: Object.values(chartData),
                animationDuration: 5000
            }
        ]
    });
    return (
        <ReactEcharts
            option={getOption()}
            style={{ height: "400px", width: "100%" }}
        />
    );
};
export default BarChart;
