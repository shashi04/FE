import React, { FunctionComponent, useEffect } from "react";
import { useState } from "react";
import { Pie } from "react-chartjs-2";
import { connect, useDispatch } from "react-redux";
import styles from "../../CommonStyles/CommonGraphStyles.module.css";
import { setClearFilter, updateStage } from "../../Redux/actions";
import { getDrillDownChartOrg } from "../../Services/analytics";
import {
  changeDateForRoute,
  fetchDrillDownAllContacts,
} from "../../Services/contacts";
import { properFormat } from "../../Values/utils";
import PieChart from "./PieCharts";


type props = {
  analyticsData: any;
  heading: string;
  type:
  | "project"
  | "location"
  | "budget"
  | "stage"
  | "propertyType"
  | "propertyStage";
  color: string[];
  GraphType: any;
  style?: any;
  role: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  contacts: any;
  user: any;
  organizationUsers: any[];
  teamLeadUsers: any;
  branchUsers: any;
};

const IntBarChartOrg: FunctionComponent<props> = ({
  analyticsData,
  heading,
  type,
  color,
  GraphType,
  style,
  role,
  history,
  filter,
  contacts,
  user,
  organizationUsers,
  teamLeadUsers,
  branchUsers,
}) => {
  const [data, setData] = useState<any>({});
  const [allContacts, setAllContacts] = useState<any[] | undefined>(undefined);

  useEffect(() => {
    let contact: any[] = [];
    Object.keys(contacts.data).forEach((key) => {
      contact = [...contact, ...contacts.data[key]];
    });
    setAllContacts(contact);
  }, [contacts.data]);

  useEffect(() => {
    const temp: { [key: string]: number } = {};
    Object.values(analyticsData).forEach((analytics: any) => {
      Object.keys(analytics.leadAnalytics[type]).forEach((key) => {
        if (temp[key]) {
          temp[key] += analytics.leadAnalytics[type][key];
        } else {
          temp[key] = analytics.leadAnalytics[type][key];
        }
      });
    });
    delete temp["Pending"];
    delete temp["Completed"];
    const sortable = Object.entries(temp)
      .sort(([, a], [, b]) => b - a)
      .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});
    if (type === "budget") {
      setData(temp);
    }
    else {
      setData(sortable);
    }
  }, [analyticsData]);
 
  const chartData = {
    labels: Object.keys(data).map((item) => properFormat(item)),
    datasets: [
      {
        label: `Interested ${type}s Summary`,
        backgroundColor: color,
        barThickness: 25,
        borderWidth: 2,
        hoverOffset: 12,
        data: Object.values(data),
      },
    ],
  };
  const dispatcher = useDispatch();
  const barOptions = {
    title: {
      display: false,
      fontSize: 20,
    },
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          // color:"#ff0000",
          font: {
            family: 'Poppins',
            // wight:800
          },
          reverse: false
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        // display:type ==='project'?true:false
        display: true
      },
      datalabels: {
        display: true,
        color: "black",
        formatter: Math.round,
        anchor: "end",
        offset: -20,
        align: "start"
      },
    }
  };
  return (
    <div className={styles.graphBox} style={style}>
      {GraphType === Pie ? <PieChart chartData={data} /> : <GraphType
        data={chartData}
        options={barOptions}
        type="line"
      />}
    </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
    role: state.user.role,
    contacts: state.contacts,
    organizationUsers: state.organizationUsers.data,
    teamLeadUsers: state.teamLeadUsers.data,
    branchUsers: state.branchUsers.data,
  };
};
export default connect(mapStateToProps)(IntBarChartOrg);
