import React, { FunctionComponent } from 'react';
import { useState } from 'react';
import { useEffect } from 'react';
import { connect, useDispatch } from 'react-redux';
import styles from '../../CommonStyles/CommonGraphStyles.module.css';
import { setClearFilter, updateStage } from '../../Redux/actions';
import {
  apiTaskDrillDown,
  taskDrillDownTableOrg,
} from '../../Services/analytics';
import { changeDateForRoute } from '../../Services/contacts';
import { sortAnalytics } from '../../Values/utils';
import * as ReactBootStrap from 'react-bootstrap';
import Table from 'react-bootstrap/Table';

type props = {
  data: any;
  type: 'Pending' | 'Completed' | 'Overdue';
  heading: string;
  usersList: any;
  checked: boolean;
  teamsData: any;
  style?: any;
  contacts: any;
  organizationUsers: any;
  filter: 'MTD' | 'YTD' | 'PM' | 'All' | 'CUSTOM';
  history: any;
  teamLeadUsers: any;
  user: any;
  source: boolean;
  taskFilter: any;
  leadFilter: any;
};

const TaskBarTable: FunctionComponent<props> = ({
  data,
  type,
  heading,
  usersList,
  checked,
  teamsData,
  style,
  contacts,
  organizationUsers,
  filter,
  history,
  teamLeadUsers,
  user,
  source,
  taskFilter,
  leadFilter,
}) => {
  const [table, setTable] = useState<any>({});
  const [tableData, setTableData] = useState<any[]>([]);
  const [allContacts, setAllContacts] = useState<any[] | undefined>(undefined);

  useEffect(() => {
    let contact: any[] = [];
    Object.keys(contacts.data).forEach((key) => {
      contact = [...contact, ...contacts.data[key]];
    });
    setAllContacts(contact);
  }, [contacts.data]);
  useEffect(() => {
    let temp: { [key: string]: {} } = {};
    Object.keys(data).forEach((key: any) => {
      temp[key] = {
        Meeting: data[key].totalTaskCount[type]['Meeting']
          ? data[key].totalTaskCount[type]['Meeting']
          : 0,
        'Call Back': data[key].totalTaskCount[type]['Call Back']
          ? data[key].totalTaskCount[type]['Call Back']
          : 0,
        'Site Visit': data[key].totalTaskCount[type]['Site Visit']
          ? data[key].totalTaskCount[type]['Site Visit']
          : 0,
      };
    });
    setTable(temp);
  }, [data]);

  useEffect(() => {
    const tempList: any[] = [];

    Object.keys(table).forEach((key) => {
      tempList.push({
        name: checked ? key : source ? key : usersList[key],
        uid: key,
        meeting: table[key]['Meeting'],
        siteVisit: table[key]['Site Visit'],
        callBack: table[key]['Call Back'],
        Total:
          table[key]['Meeting'] +
          table[key]['Site Visit'] +
          table[key]['Call Back'],
      });
    });
    let teamTempData: any[] = [];
    if (checked) {
      tempList.forEach((user) => {
        const team = teamsData[user.name];
        let existing = teamTempData.filter((item) => item.name === team);
        if (existing.length !== 0) {
          Object.keys(user).forEach((key) => {
            if (key !== 'name') {
              if (existing[0][key]) {
                existing[0][key] += user[key];
              } else {
                existing[0][key] = user[key];
              }
            }
          })
        } else {
          teamTempData.push({ ...user, name: team });

        }
      });
    }

    const finalData = checked ? teamTempData : source ? tempList : tempList;


    let gt: { [key: string]: any } = {};
    finalData.forEach((item) => {
      Object.keys(item).forEach((key) => {
        if (key !== 'name') {
          if (gt[key]) {
            gt[key] += item[key];
          } else {
            gt[key] = item[key];
          }
        }
      });
    });


    finalData.sort(sortAnalytics);
    finalData.unshift({ name: 'Grand Total', ...gt });
    setTableData(finalData.filter((item) => item.name !== undefined));
  }, [table, checked, source]);
  const dispatcher = useDispatch();

  // when a user clicks on the table data which is not zero, it opens up a drill down page, the api data for which is stored in the local storage and the necessary call is made from that page
  const getDrillDownData = async (key: string, item: any) => {
    var keyF: any;
    for (var i = 0; i < localStorage.length; i++) {
      keyF = localStorage.key(i);
      if (keyF !== 'columns') {
        localStorage.removeItem(key);
      }
    }
    dispatcher(setClearFilter(true));
    if (allContacts) {
      let mapReportingTo: { [key: string]: string } = {};
      if (organizationUsers) {
        organizationUsers.forEach((item: any) => {
          if (mapReportingTo[item.uid] === undefined) {
            mapReportingTo[item.uid] = item.reporting_to;
          }
        });
      }
      const drillDownData = await apiTaskDrillDown(
        filter,
        item.name === 'Grand Total' ? user.uid : item.uid,
        type,
        key,
        taskFilter,
        leadFilter,
        item.name === 'Grand Total' ? true : false,
        source
      );
      localStorage.setItem('taskDrilldownData', JSON.stringify(drillDownData));
      window.open('/taskDrilldownData', '_blank');
    }
  };
  return (
    <>
      <div className={styles.detailsBox} style={style}>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th
              >
                S.No
              </th>
              <th scope="col">Associate</th>

              <th scope="col" style={{textAlign:"center"}}>Total</th>

              <th scope="col" style={{textAlign:"center"}}>Meeting</th>

              <th scope="col" style={{textAlign:"center"}}>Call Back</th>
              <th scope="col" style={{textAlign:"center"}}>Site Visit</th>
            </tr>
          </thead>
          <tbody>
            {tableData.map((item, index) => (
              <>
                <tr key={index}  style={{backgroundColor:index===0?"rgb(39, 159, 159)":''}}>
                <th>{index>0?<>{index}</>:null}</th>  
                  <th
                    style={{
                      fontSize: '0.8rem',
                      fontWeight: 'bold',
                      color:index===0?"white":''
                    }}
                  >
                    {item.name}
                  </th>
                  <th
                    style={{
                      fontSize: '0.8rem',
                      fontWeight:index===0?"bold":'normal',
                      textAlign:'center',
                      cursor: item.Total !== 0 ? 'pointer' : 'not-allowed',
                      color:index===0?"white":''
                    }}
                    onClick={() =>
                      item.Total !== 0 && getDrillDownData('Total', item)
                    }
                  >
                    {item.Total}
                  </th>
                  <th
                    style={{
                      fontSize: '0.8rem',
                      color:index===0?"white":'',
                      textAlign:'center',
                      fontWeight:index===0?"bold":'normal',
                      cursor: item.meeting !== 0 ? 'pointer' : 'not-allowed',
                    }}
                    onClick={() =>
                      item.meeting !== 0 && getDrillDownData('Meeting', item)
                    }
                  >
                    {item.meeting}
                  </th>
                  <th
                    style={{
                      fontSize: '0.8rem',
                      fontWeight:index===0?"bold":'normal',
                      color:index===0?"white":'',
                      textAlign:'center',
                      cursor: item.callBack !== 0 ? 'pointer' : 'not-allowed',
                    }}
                    onClick={() =>
                      item.callBack !== 0 && getDrillDownData('Call Back', item)
                    }
                  >
                    {item.callBack}
                  </th>
                  <th
                    style={{
                      fontSize: '0.8rem',
                      fontWeight:index===0?"bold":'normal',
                      color:index===0?"white":'',
                      textAlign:'center',
                      cursor: item.siteVisit !== 0 ? 'pointer' : 'not-allowed',
                    }}
                    onClick={() =>
                      item.siteVisit !== 0 &&
                      getDrillDownData('Site Visit', item)
                    }
                  >
                    {item.siteVisit}
                  </th>
                </tr>
              </>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    contacts: state.contacts,
    organizationUsers: state.organizationUsers.data,
    teamLeadUsers: state.teamLeadUsers.data,
    user: state.user.data,
  };
};
export default connect(mapStateToProps)(TaskBarTable);
