import React, { FunctionComponent } from "react";

import makeAnimated from "react-select/animated";
import { placeholder } from "@babel/types";
type props = {
  title?: string;
  option?: any[];
  setDetails?: () => void;
  selectedValue?: any[];
  disable?: boolean;
  choices?: any[];
  Placeholder: string;
  isMulti?: boolean;
};
const animatedComponents = makeAnimated();
const MultiSelectDropdown: FunctionComponent<props> = ({
  title,
  option,
  setDetails,
  selectedValue,
  disable,
  choices,
  isMulti,
}) => {
  const choice = () => {
    if (option) {
      let data = option.map((item: any, index: number) =>
        item === "Team Lead"
          ? {
              value: item,
              label: "Team Leader",
            }
          : { value: item, label: item }
      );
      if (title) {
        data.push({ label: title, value: title });
        return data;
      } else {
        return data;
      }
    } else {
      return choices ? choices : [];
    }
  };

  return (
    <>
      <select
        placeholder="Select Items"
      />
    </>
  );
};

export default MultiSelectDropdown;
