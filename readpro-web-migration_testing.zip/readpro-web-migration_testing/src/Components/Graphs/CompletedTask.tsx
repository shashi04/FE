import React, { FunctionComponent, useEffect, useState } from "react";
import styles from "../../Screens/Analytics/Analytics.module.css";
import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";
import IntBarChartOrg from "../IntBarChartOrg/IntBarChartOrg";
import IntBarTable from "../IntBarTable/IntBarTable";
import { Pie } from "react-chartjs-2";
import TaskBarChartOrg from "../TaskBarChartOrg/TaskBarChartOrg";
import TaskBarTable from "../TaskBarChartOrg/TaskBarTable";
import {colour_code} from '../../Values/constants';
import { connect } from "react-redux";
import { CSVLink } from "react-csv";
import { DownloadReportCsv } from "../CommanDownloadFunction";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  passOnFilters: any;
  tasksFilters: any;
  completedTaskReportData:any;
};
const CompletedTask: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  passOnFilters,
  tasksFilters,
  completedTaskReportData
}) => {
  const [completeReportData, setCompleteReportData] = useState<any>([]);
  const [completeReportHeader, setCompleteReportHeader] = useState<any>([]);

  useEffect(() => {
    let headerArray: any[] = [];
    completedTaskReportData?.map((list:any)=>{
          return list?.type?.map((li:any)=>{
            return headerArray.push(li.type);
          })
    })
    setCompleteReportHeader(headerArray)
  },[completedTaskReportData]);
  
  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(completedTaskReportData,completeReportHeader, usersList,'type');
    setCompleteReportData(csvReportData);
  }
  return (
    <>
      <p style={{ marginTop: "10px",fontWeight:'bold',marginBottom:"0.5rem",fontSize:"0.9rem"}}>Completed Task Summary<CSVLink onClick={downLoadReport} data={completeReportData}> <svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)"}} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg></CSVLink></p>
      <div className="row" style={{
        display: "flex",
        width: "100%",
      }}>
        <div id="completedTasks" className={commonStyles.graphContainer} style={{
          width: "65%",
        }}>
          <TaskBarTable
            data={analyticsData}
            heading={"Completed Task Summary"}
            type={"Completed"}
            usersList={usersList}
            checked={checked}
            teamsData={teamsData}
            style={{ width: "100%" }}
            filter={filter}
            history={history}
            source={source}
            taskFilter={tasksFilters}
            leadFilter={passOnFilters}
          />
        </div>
        <div id="completedTasks" className={commonStyles.graphContainer} style={{
          width: "32%",
          marginLeft: "15px"
        }}>
          <TaskBarChartOrg
            analyticsData={analyticsData}
            type={"Completed"}
            color={colour_code}
            style={{ width: "100%" }}
            history={history}
            filter={filter}
          />
        </div>
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => {
  return {
    completedTaskReportData: state.completedTaskReportData.data,
  };
};
export default connect(mapStateToProps)(CompletedTask);
