import React, { FunctionComponent, useEffect, useState } from "react";
import styles from "../../Screens/Analytics/Analytics.module.css";
import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";
import IntBarChartOrg from "../IntBarChartOrg/IntBarChartOrg";
import IntBarTable from "../IntBarTable/IntBarTable";
import { Pie } from "react-chartjs-2";
import TaskBarChartOrg from "../TaskBarChartOrg/TaskBarChartOrg";
import TaskBarTable from "../TaskBarChartOrg/TaskBarTable";
import {colour_code} from '../../Values/constants';
import { connect } from "react-redux";
import { CSVLink } from "react-csv";
import { DownloadReportCsv } from "../CommanDownloadFunction";
import { useRowState } from "react-table";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  passOnFilters: any;
  tasksFilters: any;
  overDueReportData:any;
};

const OverdueTask: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  passOnFilters,
  tasksFilters,
  overDueReportData
}) => {
  const [overDuReportData, setOverDueReportData] = useState<any>([]);
  const [overDueReportHeader, setOverDueReportHeader] = useState<any>([]);

  useEffect(() => {
    let headerArray: any[] = [];
    overDueReportData?.map((list: any) => {
      return list?.type?.map((li: any) => {
        return headerArray.push(li.type);
      })
    })
    setOverDueReportHeader(headerArray)
  }, [overDueReportData]);

  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(overDueReportData,overDueReportHeader, usersList, 'type');
    setOverDueReportData(csvReportData);
  }
  return (
    <>
       <p style={{ marginTop: "10px", fontWeight: 'bold', marginBottom: "0.5rem", fontSize: "0.9rem" }}>Overdue Task Summary<CSVLink onClick={downLoadReport} data={overDuReportData}> <svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)" }} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg></CSVLink></p>
      <div className="row" style={{
        display: "flex",
        width: "100%",
      }}>
        <div id="overdueTasks" className={commonStyles.graphContainer} style={{
          width: "32%",
        }}>
          <TaskBarChartOrg
            analyticsData={analyticsData}
            type={"Overdue"}
            color={colour_code}
            style={{ width: "100%" }}
            history={history}
            filter={filter}
          />
        </div>
        <div id="overdueTasks" className={commonStyles.graphContainer} style={{
          width: "65%",
          marginLeft: "15px"
        }}>
          <TaskBarTable
            data={analyticsData}
            heading={"Overdue Task Summary"}
            type={"Overdue"}
            usersList={usersList}
            checked={checked}
            teamsData={teamsData}
            style={{ width: "100%" }}
            filter={filter}
            history={history}
            source={source}
            taskFilter={tasksFilters}
            leadFilter={passOnFilters}
          />
        </div>
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => {
  return {
    overDueReportData: state.overDueReportData.data,
  };
};
export default connect(mapStateToProps)(OverdueTask);
