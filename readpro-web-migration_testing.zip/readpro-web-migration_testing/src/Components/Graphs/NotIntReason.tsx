import React, { FunctionComponent, useEffect, useState } from "react";

import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";

import IntBarTable from "../IntBarTable/IntBarTable";

import DoughnutChartOrg from "../DoughnutChartOrg/DoughnutChartOrg";
import { colour_code } from "../../Values/constants";
import { connect } from "react-redux";
import { sortAnalytics } from "../../Values/utils";
import { CSVLink } from "react-csv";
import { DownloadReportCsv } from "../CommanDownloadFunction";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  taskFilter: any;
  leadFilter: any;
  notInterestedReportData:any;
};

const NotIntReason: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  taskFilter,
  leadFilter,
  notInterestedReportData
}) => {
  const [notInterestedData, setNotInterestedReportData] = useState<any>([]);
  const [notInterestedHeader, setNotInterestedReportHeader] = useState<any>([]);

  useEffect(() => {
    let headerArray: any[] = [];
    notInterestedReportData?.map((list:any)=>{
          return list?.not_int_reason?.map((li:any)=>{
            return headerArray.push(li.not_int_reason);
          })
    });
    setNotInterestedReportHeader(headerArray);
  }, [notInterestedReportData]);
  
  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(notInterestedReportData,notInterestedHeader, usersList,'not_int_reason');
    setNotInterestedReportData(csvReportData);
  }
  return (
    <>
     <p style={{ marginTop: "30px",fontWeight:'bold',marginBottom:"0.5rem",fontSize:"0.9rem"}}>Not Interseted Reason Summary<CSVLink onClick={downLoadReport} data={notInterestedData}><svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)" }} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg> </CSVLink></p>
      <div className="row" style={{
        display: "flex",
        width: "100%",
      }}>
        <div id="notIntReason" className={commonStyles.graphContainer} style={{
          width: "65%",
        }}>
          <IntBarTable
            data={analyticsData}
            type={"not_int_reason"}
            heading={"Not Interseted Reason Summary"}
            usersList={usersList}
            checked={checked}
            teamsData={teamsData}
            style={{ width: "100%" }}
            filter={filter}
            history={history}
            source={source}
            taskFilter={taskFilter}
            leadFilter={leadFilter}
          />

        </div>
        <div id="notIntReason" className={commonStyles.graphContainer} style={{
          width: "32%",
          marginLeft: "15px"
        }}>
          <DoughnutChartOrg
            analyticsData={analyticsData}
            type={"not_int_reason"}
            color={colour_code}
            style={{ width: "90%", height: "320px" }}
            history={history}
            filter={filter}
          />
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    notInterestedReportData: state.notInterestedReportData.data,
  };
};
export default connect(mapStateToProps)(NotIntReason);
