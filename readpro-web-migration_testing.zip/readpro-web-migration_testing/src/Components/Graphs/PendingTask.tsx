import React, { FunctionComponent, useEffect, useState } from "react";
import styles from "../../Screens/Analytics/Analytics.module.css";
import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";
import IntBarChartOrg from "../IntBarChartOrg/IntBarChartOrg";
import IntBarTable from "../IntBarTable/IntBarTable";
import { Pie } from "react-chartjs-2";
import TaskBarChartOrg from "../TaskBarChartOrg/TaskBarChartOrg";
import TaskBarTable from "../TaskBarChartOrg/TaskBarTable";
import {colour_code} from '../../Values/constants';
import { connect } from "react-redux";
import { DownloadReportCsv } from "../CommanDownloadFunction";
import { CSVLink } from "react-csv";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  passOnFilters: any;
  tasksFilters: any;
  pendingTaskReportData:any;
};

const PendingTask: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  passOnFilters,
  tasksFilters,
  pendingTaskReportData
}) => {
  const [pendingReportData, setPendingReportData] = useState<any>([]);
  const [pendingReportHeader, setPendingReportHeader] = useState<any>([]);

  useEffect(() => {
    let headerArray: any[] = [];
    pendingTaskReportData?.map((list:any)=>{
          return list?.type?.map((li:any)=>{
            return headerArray.push(li.type);
          })
    })
    setPendingReportHeader(headerArray)
  },[pendingTaskReportData]);

  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(pendingTaskReportData,pendingReportHeader, usersList,'type');
    setPendingReportData(csvReportData);
  }
  return (
    <>
        <p style={{ marginTop: "10px",fontWeight:'bold',marginBottom:"0.5rem",fontSize:"0.9rem"}}>Pending Task Summary<CSVLink onClick={downLoadReport} data={pendingReportData}> <svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)"}} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg></CSVLink></p>
      <div className="row" style={{
        display: "flex",
        width: "100%",
      }}>
        <div id="scheduledTasks" className={commonStyles.graphContainer} style={{
          width: "65%",
        }}>
          <TaskBarTable
            data={analyticsData}
            heading={"Pending Task Summary"}
            type={"Pending"}
            usersList={usersList}
            checked={checked}
            teamsData={teamsData}
            style={{ width: "100%" }}
            filter={filter}
            history={history}
            source={source}
            taskFilter={tasksFilters}
            leadFilter={passOnFilters}
          />

        </div>
        <div id="scheduledTasks" className={commonStyles.graphContainer} style={{
          width: "32%",
          marginLeft: "15px"
        }}>
          <TaskBarChartOrg
            analyticsData={analyticsData}
            type={"Pending"}
            color={colour_code}
            style={{ width: "100%" }}
            history={history}
            filter={filter}
          />
        </div>
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => {
  return {
    pendingTaskReportData: state.pendingTaskReportData.data,
  };
};
export default connect(mapStateToProps)(PendingTask);
