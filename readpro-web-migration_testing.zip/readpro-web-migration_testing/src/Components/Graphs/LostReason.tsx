import React, { FunctionComponent, useEffect, useState } from "react";
import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";
import IntBarTable from "../IntBarTable/IntBarTable";
import DoughnutChartOrg from "../DoughnutChartOrg/DoughnutChartOrg";
import { colour_code } from "../../Values/constants";
import { sortAnalytics } from "../../Values/utils";
import { connect } from "react-redux";
import { CSVLink } from "react-csv";
import { DownloadReportCsv } from "../CommanDownloadFunction";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  taskFilter: any;
  leadFilter: any;
  lostReasonReportData:any;
};

const LostReason: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  taskFilter,
  leadFilter,
  lostReasonReportData
}) => {
  const [lostReasonData, setLostReasonReportData] = useState<any>([]);
  const [lostReasonHeader, setLostReasonReportHeader] = useState<any>([]);
  useEffect(() => {
    let headerArray: any[] = [];
    lostReasonReportData?.map((list:any)=>{
          return list?.lost_reason?.map((li:any)=>{
            return headerArray.push(li.lost_reason);
          })
    })
  }, [lostReasonReportData]);
  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(lostReasonReportData,lostReasonHeader, usersList,'lost_reason');
    setLostReasonReportData(csvReportData);
  }
  return (
    <>
     <p style={{ marginTop: "30px",fontWeight:'bold',marginBottom:"0.5rem",fontSize:"0.9rem"}}>Lost reason Summary<CSVLink onClick={downLoadReport} data={lostReasonData}><svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)" }} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg> </CSVLink></p>
      <div className="row" style={{
        display: "flex",
        width: "100%",
      }}>
        <div id="lostReason" className={commonStyles.graphContainer} style={{
          width: "32%",
        }}>
          <DoughnutChartOrg
            analyticsData={analyticsData}
            type={"lost_reason"}
            color={colour_code}
            style={{ width: "90%", height: "320px" }}
            history={history}
            filter={filter}
          />
        </div>

        <div id="lostReason" className={commonStyles.graphContainer} style={{
          width: "65%",
          marginLeft: "15px"
        }}>
          <IntBarTable
            data={analyticsData}
            type={"lost_reason"}
            heading={"Lost Reason Summary"}
            usersList={usersList}
            checked={checked}
            teamsData={teamsData}
            style={{ width: "100%" }}
            filter={filter}
            history={history}
            source={source}
            taskFilter={taskFilter}
            leadFilter={leadFilter}
          />
        </div>
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => {
  return {
    lostReasonReportData: state.lostReasonReportData.data,
  };
};
export default connect(mapStateToProps)(LostReason);
