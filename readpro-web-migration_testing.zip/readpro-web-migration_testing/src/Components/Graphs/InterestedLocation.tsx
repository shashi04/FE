import React, { FunctionComponent, useEffect, useState } from "react";
import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";
import IntBarChartOrg from "../IntBarChartOrg/IntBarChartOrg";
import IntBarTable from "../IntBarTable/IntBarTable";
import { Bar } from "react-chartjs-2";
import { colour_code } from '../../Values/constants';
import { connect } from "react-redux";
import { sortAnalytics } from "../../Values/utils";
import { CSVLink } from "react-csv";
import { DownloadReportCsv } from "../CommanDownloadFunction";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  taskFilter: any;
  leadFilter: any;
  interestedLocationReportData:any;
};

const InterestedLocation: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  taskFilter,
  leadFilter,
  interestedLocationReportData
}) => {
  const [interestedLocationData, setInterestedLocationReportData] = useState<any>([]);
  const [interestedLocationReportHeader, setInterestedLocationReportHeader] = useState<any>([]);
  useEffect(() => {
    let headerArray: any[] = [];
    interestedLocationReportData?.map((list:any)=>{
          return list?.location?.map((li:any)=>{
            return headerArray.push(li.location);
          })
    })
    setInterestedLocationReportHeader(headerArray);
  }, [interestedLocationReportData]);
  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(interestedLocationReportData, interestedLocationReportHeader, usersList,'location');
    setInterestedLocationReportData(csvReportData);
  }
  return (
    <>
    <p style={{ marginTop: "30px",fontWeight:'bold',marginBottom:"0.5rem",fontSize:"0.9rem"}}>Interested Location Summary<CSVLink onClick={downLoadReport} data={interestedLocationData}> <svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)" }} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg> </CSVLink></p>
      <div id="interestedLocation" className={commonStyles.graphContainer} style={{
      }}>
        <IntBarChartOrg
          analyticsData={analyticsData}
          heading={"Interested Locations"}
          type={"location"}
          color={colour_code}
          GraphType={Bar}
          style={{ width: "100%", height: "350px" }}
          history={history}
          filter={filter}
        />
      </div>
      <div id="interestedLocation" className={commonStyles.graphContainer} style={{
      }}>
        <IntBarTable
          type={"location"}
          data={analyticsData}
          heading={"Interested Location Summary"}
          usersList={usersList}
          checked={checked}
          teamsData={teamsData}
          style={{ width: "100%" }}
          show={false}
          filter={filter}
          history={history}
          source={source}
          taskFilter={taskFilter}
          leadFilter={leadFilter}
        />
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => {
  return {
    interestedLocationReportData: state.interestedLocationdata.data,
  };
};
export default connect(mapStateToProps)(InterestedLocation);
