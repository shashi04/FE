import React, { FunctionComponent, useEffect, useState } from "react";
import commonStyles from "../../CommonStyles/CommonGraphStyles.module.css";
import IntBarChartOrg from "../IntBarChartOrg/IntBarChartOrg";
import IntBarTable from "../IntBarTable/IntBarTable";
import { Pie } from "react-chartjs-2";
import {colour_code} from '../../Values/constants';
import { sortAnalytics } from "../../Values/utils";
import { connect } from "react-redux";
import { CSVLink } from "react-csv";
import { DownloadReportCsv } from "../CommanDownloadFunction";

type props = {
  analyticsData: any;
  usersList: any;
  checked: boolean;
  teamsData: any;
  history: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM";
  source: boolean;
  taskFilter: any;
  leadFilter: any;
  interestedPropertTypeReportData:any;
};

const InterestedPropertyType: FunctionComponent<props> = ({
  analyticsData,
  usersList,
  checked,
  history,
  teamsData,
  filter,
  source,
  taskFilter,
  leadFilter,
  interestedPropertTypeReportData
}) => {
  const [interestedProjectTypeData, setInterestedProjectTypeReportData] = useState<any>([]);
  const [interestedPropertyTypeReportHeader, setInterestedPropertyTypeReportHeader] = useState<any>([]);
  useEffect(() => {
    let headerArray: any[] = [];
    interestedPropertTypeReportData?.map((list:any)=>{
          return list?.property_type?.map((li:any)=>{
            return headerArray.push(li.property_type);
          })
    })
    setInterestedPropertyTypeReportHeader(headerArray);
  }, [interestedPropertTypeReportData]);
  const downLoadReport = () => {
    const csvReportData = DownloadReportCsv(interestedPropertTypeReportData,interestedPropertyTypeReportHeader, usersList,'property_type');
    setInterestedProjectTypeReportData(csvReportData);
  }
  return (
    <>
       <p style={{ marginTop: "30px",fontWeight:'bold',marginBottom:"0.5rem",fontSize:"0.9rem"}}>Interested Property Type Summary<CSVLink onClick={downLoadReport} data={interestedProjectTypeData}> <svg style={{ cursor: 'pointer',color:"rgb(39, 159, 159)" }} xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-download" viewBox="0 0 16 16">
        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
      </svg> </CSVLink></p>
      <div className="row" style={{
        display: "flex",
        width: "100%",
      }}>
        <div id="propertyType" className={commonStyles.graphContainer} style={{
          width: "65%",
        }}>
           <IntBarTable
            type={"propertyType"}
            data={analyticsData}
            heading={"Interested Property Type Summary"}
            usersList={usersList}
            checked={checked}
            teamsData={teamsData}
            style={{ width: "100%" }}
            filter={filter}
            history={history}
            source={source}
            taskFilter={taskFilter}
            leadFilter={leadFilter}
          />
        </div>
        <div id="propertyType" className={commonStyles.graphContainer} style={{
          width: "32%",
          marginLeft: "15px"
        }}>
           <IntBarChartOrg
            analyticsData={analyticsData}
            heading={"Interested Property Type"}
            type={"propertyType"}
            color={colour_code}
            GraphType={Pie}
            style={{ width: "100%", height: "350px" }}
            history={history}
            filter={filter}
          />
         
        </div>
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => {
  return {
    interestedPropertTypeReportData: state.interestedPropertyTypeData.data,
  };
};
export default connect(mapStateToProps)(InterestedPropertyType);
