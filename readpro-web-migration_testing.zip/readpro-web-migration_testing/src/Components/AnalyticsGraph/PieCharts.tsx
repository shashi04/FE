import React, { FunctionComponent, useEffect, useState } from "react";
import ReactEcharts from "echarts-for-react";
import { properFormat } from "../../Values/utils";
import './Chart.style.css'
import { colour_code } from "../../Values/constants";

type props = {
    chartData: any;
};
const PieChart: FunctionComponent<props> = ({ chartData }) => {
    const [arrchartData, setArrChartData] = useState<any>([]);

    useEffect(() => {
        let arrChartData = [];
        let lables = chartData.labels;
        let values = chartData.datasets?.[0]?.data;
        const c_Data = Object.fromEntries(lables.map((_: any, i: any) => [lables[i], values[i]]))
        for (const [key, value] of Object.entries(c_Data)) {
            arrChartData.push({ value: value, name: properFormat(key) },)
        }
        setArrChartData(arrChartData);
    }, [chartData])

    const getOption = () => ({
        tooltip: {
            trigger: "item",
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            orient: "horizontal",
            bottom: "bottom",
            data: properFormat(chartData?.labels),
        },
        series: [
            {
                name: "",
                type: "pie",
                radius: "55%",
                center: ["50%", "60%"],
                animationDuration: 5000,
                data: arrchartData,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: "rgba(0, 0, 0, 0.5)"
                    }
                }
            },
        ],
        color: colour_code,
    });
    return (
        <ReactEcharts
            option={getOption()}
            style={{ height: "400px", width: "100%", bottom: "100px", top: "none" }}
        />
    );
};
export default PieChart;
