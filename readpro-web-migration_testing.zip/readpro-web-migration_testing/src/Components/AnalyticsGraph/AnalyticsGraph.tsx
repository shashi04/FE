import React, { FunctionComponent } from "react";
import { useEffect } from "react";
import { useState } from "react";
import { Pie } from "react-chartjs-2";
import { connect, useDispatch } from "react-redux";
import { setClearFilter } from "../../Redux/actions";
import {
  drillDownTableOrg,
  getDrillDownChartOrg,
  getInterestedLeadsDrillDown,
  getTaskDrillDownChartSales,
  getTaskDrillDownTableSales,
} from "../../Services/analytics";
import { changeDateForRoute } from "../../Services/contacts";
import { properFormat } from "../../Values/utils";
import PieChart from "./PieCharts";
import styles from "./AnalyticsGraph.module.css";

type props = {
  GraphType: any;
  data: any;
  Heading: string;
  stage?: any;
  title: string;
  value: string;
  role: string;
  history: any;
  contacts: any;
  filter: "MTD" | "YTD" | "PM" | "All" | "CUSTOM" | "T" | "Y";
  type:
  | "project"
  | "location"
  | "budget"
  | "stage"
  | "property_type"
  | "property_stage"
  | "other"
  | "Overdue"
  | "Pending"
  | "Completed";
  user: any;
  organizationUsers: any[];
  teamLeadUsers: any[];
};
const AnalyticsGraph: FunctionComponent<props> = ({
  GraphType,
  data,
  Heading,
  stage,
  title,
  value,
  role,
  history,
  contacts,
  filter,
  type,
  user,
  organizationUsers,
  teamLeadUsers,
}) => {
  const [tableData, setTableData] = useState<any[]>([]);
  const [allContacts, setAllContacts] = useState<any[] | undefined>(undefined);

  useEffect(() => {
    let contact: any[] = [];
    Object.keys(contacts.data).forEach((key) => {
      contact = [...contact, ...contacts.data[key]];
    });
    setAllContacts(contact);
  }, [contacts.data]);
  useEffect(() => {
    if (
      (Heading === "FeedBack" ||
        Heading === "Interested Budget Summary" ||
        Heading === "Interested Location Summary" ||
        Heading === "Interested Project Summary" ||
        Heading === "Over Due Tasks" ||
        Heading === "Pending Tasks") &&
      stage
    ) {
      const tempList: any[] = [];
      Object.keys(stage).forEach((key) => {
        tempList.push({
          val: key === "" ? "Undefined" : key,
          count: stage[key],
        });
      });
      if (Heading !== "Over Due Tasks" && Heading !== "Pending Tasks") {
        let gt = 0;
        tempList.forEach((item) => {
          gt += item.count;
        });
        tempList.unshift({ val: "Grand Total", count: gt });
      }

      setTableData(tempList);
    }
    if (Heading === "Completed Tasks") {
      const tempList: any[] = [];
      Object.keys(stage).forEach((key) => {
        tempList.push({
          val: key === "" ? "Undefined" : key,
          count: stage[key]["Completed"],
        });
      });
      setTableData(tempList);
    }
  }, [stage]);
  const dispatcher = useDispatch();
  const barOptions = {
    title: {
      display: false,
      fontSize: 20,
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display:true
      },
       datalabels: {
          display: true,
          color: "black",
          formatter: Math.round,
          anchor: "end",
          offset: -20,
          align: "start"
        },
    }
  };
  return (
    <div className={styles.graphContainer}>
    <div
      className={styles.graphBox}
      style={
        Heading === "Completed vs. Overdue" ||
          Heading === "Call Log Trends Summary" ||
          Heading === "Call Log Trends" ||
          Heading === "Interested Lead Trends" ||
          Heading === "Interested Lead Trends Summary"
          ? { width: "100%" }
          : {}
      }
    >
      {GraphType === Pie ? <PieChart chartData={data} /> : <GraphType
        data={data}
        options={barOptions}
        type="line"
      />}
    </div>
    <div
      className={styles.line}
      style={
        Heading === "Completed vs. Overdue" ||
          Heading === "Call Log Trends Summary" ||
          Heading === "Call Log Trends" ||
          Heading === "Interested Lead Trends" ||
          Heading === "Interested Lead Trends Summary"
          ? { height: "0%" }
          : {}
      }
    >
    </div>
    {(Heading === "FeedBack" ||
      Heading === "Interested Budget Summary" ||
      Heading === "Interested Project Summary" ||
      Heading === "Interested Location Summary") && (
        <div className={styles.detailsBox}>
          <p className={styles.graphHeading}>{Heading}</p>
          <div className={styles.typeBox}>
            <p className={styles.text}>{properFormat(title)}</p>
            <p className={styles.text}>{properFormat(value)}</p>
          </div>
          <div className={styles.graphLine}></div>
          {tableData.map((item, index) => (
            <>
              <div className={styles.typeBox}>
                <p className={styles.text}>{properFormat(item.val)}</p>
                <p
                  className={styles.text}
                >
                  {item.count}
                </p>
              </div>
              <div className={styles.graphLine}></div>
            </>
          ))}
        </div>
      )}

    {(Heading === "Over Due Tasks" ||
      Heading === "Completed Tasks" ||
      Heading === "Pending Tasks") && (
        <div className={styles.detailsBox}>
          <p className={styles.graphHeading}>{Heading}</p>
          <div className={styles.typeBox}>
            <p className={styles.text}>Date</p>
            <p className={styles.text} style={{ marginLeft: "50px" }}>
              Meeting
            </p>
            <p className={styles.text}>Call Back</p>
            <p className={styles.text}>Site Visit</p>
          </div>
          <div className={styles.graphLine}></div>
          {tableData.map((item, index) => (
            <>
              <div className={styles.typeBox}>
                <p className={styles.text}>{item.val}</p>
                <p
                  className={styles.text}
                >
                  {item.count.Meeting}
                </p>
                <p
                  className={styles.text}
                >
                  {item.count["Call Back"]}
                </p>
                <p
                  className={styles.text}
                >
                  {item.count["Site Visit"]}
                </p>
              </div>
              <div className={styles.graphLine}></div>
            </>
          ))}
        </div>
      )}
  </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    role: state.user.role,
    contacts: state.contacts,
    user: state.user.data,
    organizationUsers: state.organizationUsers.data,

    teamLeadUsers: state.teamLeadUsers.data,
  };
};

export default connect(mapStateToProps)(AnalyticsGraph);
