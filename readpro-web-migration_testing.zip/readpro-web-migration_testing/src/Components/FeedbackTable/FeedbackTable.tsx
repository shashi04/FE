import React, { FunctionComponent } from "react";
import styles from "./FeedbackTable.module.css";

type props = {};

const FeedbackTable: FunctionComponent<props> = ({}) => {
  return (
    <div style={{ width: "100%", height: "300px", backgroundColor: "white" }} />
  );
};

export default FeedbackTable;
