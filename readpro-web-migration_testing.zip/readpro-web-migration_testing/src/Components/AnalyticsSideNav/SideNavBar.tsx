import React, {
  FunctionComponent,
  useEffect,
  useState,
} from "react";
import { styled, useTheme, Theme, CSSObject } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar, { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import MailIcon from '@mui/icons-material/Mail';
import './sideNavBar.style.css';
import classNames from "classnames";
import styles from "../Navbar/Navbar.module.css";
import analyticsIcon from "../../Assets/Images/analytics.svg";
import activeAnalyticsIcon from '../../Assets/Images/analyticsActive.svg'
import contactsIcon from "../../Assets/Images/contact-info-1.svg";
import contactsIconActive from "../../Assets/Images/contact-info-Active.svg";
import projectIcon from "../../Assets/Images/checklist.svg";
import projectIconActive from "../../Assets/Images/checklistActive.svg";
import tasksIcon from "../../Assets/Images/paper.svg";
import tasksIconActive from "../../Assets/Images/paperActive.svg";
import resourcesIcon from "../../Assets/Images/globe.svg";
import resourcesIconActive from "../../Assets/Images/globeActive.svg";
import callLogsIcon from "../../Assets/Images/call.svg";
import callLogsIconActive from "../../Assets/Images/callActive.svg";
import faqIcon from "../../Assets/Images/faq.svg";
import faqIconActive from "../../Assets/Images/faqActive.svg";
import apiIcon from "../../Assets/Images/cloud-api (2).svg";
import apiIconActive from "../../Assets/Images/cloud-api-Active.svg";
import leadDIcon from "../../Assets/Images/leader.svg";
import leadDIconActive from "../../Assets/Images/leaderActive.svg";
import newsIconActive from "../../Assets/Images/newsActive.svg";
import newsIcon from "../../Assets/Images/news.svg";
import userIcon from "../../Assets/Images/user.svg";
import userIconActive from "../../Assets/Images/userActive.svg";
import clearFilterIcon from "../../Assets/Images/filter-remove.svg"
import { setClearFilter } from "../../Redux/actions";
import { connect, useDispatch } from 'react-redux';

const drawerWidth = 240;

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled('div')(({ theme: any }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
}));

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})<AppBarProps>(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    ...(open && {
      ...openedMixin(theme),
      '& .MuiDrawer-paper': openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      '& .MuiDrawer-paper': closedMixin(theme),
    }),
  }),
);

type props = {
  props?: any;
  title:
  | "Organizations"
  | "Contacts"
  | "Users"
  | "Drilldown";
  path?: string;
  leadManger?: Boolean;
  project?: string;
  task?: string;
  resources?: string;
  callLogs?: string;
  faq?: string;
  user: any;
  api?: string;
  news?: string;
  apiData?: string;
  leadDistributor?: string;
  customButton?: string;
};
const MiniDrawer: FunctionComponent<props> = ({
  props,
  title,
  path,
  leadManger,
  project,
  task,
  resources,
  callLogs,
  faq,
  user,
  api,
  news,
  apiData,
  leadDistributor,
  customButton,
}) => {
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);
  const dispatcher = useDispatch();

  const handleDrawer = () => {
    if (!open) {
      setOpen(true);
    }
    else {
      setOpen(false);
    }

  };
  console.log("opendata", open);
  return (
    <Box className="containerSideBar" sx={{ display: 'flex' }} >
      <Drawer variant="permanent" open={open}   >
        <DrawerHeader >
          <IconButton onClick={handleDrawer} style={{ marginRight: "10px" }}>
            {open ? <ChevronLeftIcon /> : <MenuIcon />}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List style={{ paddingBottom: "100px" }}>
          {title !== "Drilldown" && title !== "Users" && (
            <ListItem disablePadding sx={{ display: 'block' }}
              style={{
                backgroundColor: "/analytics" ===
                  props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                color: "/analytics" ===
                  props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
              }}
              onClick={() => {
                props.history.push("/analytics");
              }}
            >
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                }}

              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={"/analytics" ===
                      props.history.location.pathname ? activeAnalyticsIcon : analyticsIcon}
                    alt=""
                    width={"20px"}
                  />
                </ListItemIcon>
                <ListItemText primary={"Analytics"}
                  sx={{ opacity: open ? 1 : 0 }} />
              </ListItemButton>
              {!open ? <span>Analytics</span> : ''}
            </ListItem>
          )}
          <ListItem disablePadding sx={{ display: 'block' }}
            style={{
              backgroundColor: path === props.history.location.pathname ? "#279f9f" : "white",
              color: path ===
                props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
            }}
            onClick={() => {
              props.history.push(path);
            }}
          >
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}

            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 3 : 'auto',
                  justifyContent: 'center',
                }}
              >
                <img
                  src={title === "Users" ? path ===
                    props.history.location.pathname ? userIconActive : userIcon : path ===
                      props.history.location.pathname ? contactsIconActive : contactsIcon}
                  alt=""
                  width={"20px"}
                />
              </ListItemIcon>
              <ListItemText primary={title} sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
            {!open ? <span style={{marginLeft:title === "Users"?"10px":""}}>{title}</span> : ''}
          </ListItem>
          {title !== "Drilldown" &&
            (user.profile === "Lead Manager" ||
              user.profile === "Sales" ||
              user.profile === "Team Lead") && (
              <ListItem disablePadding sx={{ display: 'block' }}
                style={{
                  backgroundColor: task === props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                  color: task ===
                    props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
                }}
                onClick={() => {
                  props.history.push("/tasks");
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={task === props.history.location.pathname ? tasksIconActive : tasksIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"Tasks"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span style={{ marginLeft: "10px" }}>Tasks</span> : ''}
              </ListItem>
            )}

          {title !== "Drilldown" && leadManger === true && (
            <>
              <ListItem disablePadding sx={{ display: 'block' }}
                style={{
                  backgroundColor: "/projects" ===
                    props.history.location.pathname ? "#279f9f" : "white",
                  color: "/projects" ===
                    props.history.location.pathname ? "white" : "", cursor: "pointer"
                }}
                onClick={() => {
                  props.history.push("/projects");
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={"/projects" ===
                        props.history.location.pathname ? projectIconActive : projectIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"Projects"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span style={{ marginLeft: "5px" }}>Projects</span> : ''}
              </ListItem>
              <ListItem disablePadding sx={{ display: 'block' }}
                style={{
                  backgroundColor: "/resources" ===
                    props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                  color: "/resources" ===
                    props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
                }}
                onClick={() => {
                  props.history.push("/resources");
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={"/resources" ===
                        props.history.location.pathname ? resourcesIconActive : resourcesIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"Resources"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span>Resourc..</span> : ''}
              </ListItem>
              <ListItem disablePadding sx={{ display: 'block' }}
                style={{
                  backgroundColor: "/callLogs" ===
                    props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                  color: "/callLogs" ===
                    props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
                }}
                onClick={() => {
                  props.history.push("/callLogs");
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={"/callLogs" ===
                        props.history.location.pathname ? callLogsIconActive : callLogsIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"Call Logs"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span>Call Logs</span> : ''}
              </ListItem>
              <ListItem disablePadding sx={{ display: 'block' }}
                style={{
                  backgroundColor: "/faq" ===
                    props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                  color: "/faq" ===
                    props.history.location.pathname ? "#FFFFFF" : "", cursor: 'pointer'
                }}
                onClick={() => {
                  props.history.push("/faq");
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={"/faq" ===
                        props.history.location.pathname ? faqIconActive : faqIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"FAQ"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span style={{ marginLeft: "17px" }}>FAQ</span> : ''}
              </ListItem>
              <ListItem disablePadding sx={{ display: 'block' }}
                style={{
                  backgroundColor: "/apiData" ===
                    props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                  color: "/apiData" ===
                    props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
                }}
                onClick={() => {
                  props.history.push("/apiData");
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={"/apiData" ===
                        props.history.location.pathname ? apiIconActive : apiIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"API"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span style={{ marginLeft: "18px" }}>API</span> : ''}
              </ListItem>
              <ListItem disablePadding sx={{ display: 'block' }}
                onClick={() => {
                  props.history.push("/leadDistributor");
                }}
                style={{
                  backgroundColor: "/leadDistributor" ===
                    props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                  color: "/leadDistributor" ===
                    props.history.location.pathname ? "#FFFFFF" : "", cursor: "pointer"
                }}
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 3 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    <img
                      src={"/leadDistributor" ===
                        props.history.location.pathname ? leadDIconActive : leadDIcon}
                      alt=""
                      width={"20px"}
                    />
                  </ListItemIcon>
                  <ListItemText primary={"Lead Distribution"} sx={{ opacity: open ? 1 : 0 }} />
                </ListItemButton>
                {!open ? <span>Lead Dist..</span> : ''}
              </ListItem>
            </>
          )}
          {api && (
            <ListItem disablePadding sx={{ display: 'block' }}
              style={{
                backgroundColor: api === props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                color: api ===
                  props.history.location.pathname ? "#FFFFFF" : "", cursor: 'pointer'
              }}
              onClick={() => {
                props.history.push(api);
              }}
            >
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={api === props.history.location.pathname ? apiIconActive : apiIcon}
                    alt=""
                    width={"20px"}
                  />
                </ListItemIcon>
                <ListItemText primary={"API"} sx={{ opacity: open ? 1 : 0 }} />
              </ListItemButton>
              {!open ? <span style={{ marginLeft: "18px" }}>API</span> : ''}
            </ListItem>
          )}
          {news && (
            <ListItem disablePadding sx={{ display: 'block' }}
              style={{
                backgroundColor: news === props.history.location.pathname ? "#279f9f" : "#FFFFFF",
                color: news ===
                  props.history.location.pathname ? "#FFFFFF" : "",cursor:"pointer"
              }}
              onClick={() => {
                props.history.push(news);
              }}
            >
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                }}

              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={news === props.history.location.pathname ? newsIconActive : newsIcon}
                    alt=""
                    width={"20px"}
                  />
                </ListItemIcon>
                <ListItemText primary={"NEWS"} sx={{ opacity: open ? 1 : 0 }} />
              </ListItemButton>
              {!open ? <span style={{ marginLeft: "10px" }}>NEWS</span> : ''}
            </ListItem>
          )}
          {customButton && (
            <ListItem disablePadding sx={{ display: 'block' }}
            style={{
              backgroundColor: customButton ===
                props.history.location.pathname ? "#279f9f" : "#FFFFFF",
              color: customButton ===
                props.history.location.pathname ? "#FFFFFF" : "",cursor:"pointer"
            }}
            onClick={() => {
              props.history.push(customButton);
            }}
            >
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                }}
              
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={customButton ===
                      props.history.location.pathname ? apiIconActive : apiIcon}
                    alt=""
                    width={"20px"}
                  />
                </ListItemIcon>
                <ListItemText primary={"Custom Button"} sx={{ opacity: open ? 1 : 0 }} />
              </ListItemButton>
              {!open ? <span>Custom B.</span> : ''}
            </ListItem>
          )}
          {title === "Contacts" && leadManger === false && (
            <ListItem disablePadding sx={{ display: 'block' }}
            style={{
              backgroundColor: callLogs === props.history.location.pathname ? "#279f9f" : "#FFFFFF",
              color: callLogs ===
                props.history.location.pathname ? "#FFFFFF" : "",
            }}
            onClick={() => {
              props.history.push(callLogs);
            }}
            >
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                }}
               
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={callLogs === props.history.location.pathname ? callLogsIconActive : callLogsIcon}
                    alt=""
                    width={"20px"}
                  />
                </ListItemIcon>
                <ListItemText primary={"Call Logs"} sx={{ opacity: open ? 1 : 0 }} />
              </ListItemButton>
              {!open ? <span>Call Logs</span> : ''}
            </ListItem>
          )}
        </List>
      </Drawer>
    </Box >
  );
}
const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
  };
};

export default connect(mapStateToProps)(MiniDrawer);