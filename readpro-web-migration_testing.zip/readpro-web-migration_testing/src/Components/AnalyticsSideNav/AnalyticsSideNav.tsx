import React, { FunctionComponent } from "react";
import styles from "../../Screens/Analytics/Analytics.module.css";
import {
  AiFillPieChart,
  AiOutlineBarChart,
  AiOutlineDotChart,
} from "react-icons/ai";
import { FiBarChart2, FiBarChart } from "react-icons/fi";
import { BiBarChart } from "react-icons/bi";
import { BsGraphUp } from "react-icons/bs";
import PersistentDrawerLeft from "./SideNavBar";

type props = {
  props?: any;
  title:
  | "Organizations"
  | "Contacts"
  | "Users"
  | "Drilldown";
  path: string;
  leadManger: Boolean;
  project?: string;
  task?: string;
  resources?: string;
  callLogs?: string;
  faq?: string;
  api?: string;
  news?: string;
  apiData?: string;
  leadDistributor?: string;
  customButton?: string;
};

const AnalyticsSideNav: FunctionComponent<props> = ({
  props,
  title,
  path,
  leadManger,
  project,
  task,
  resources,
  callLogs,
  faq,
  api,
  news,
  apiData,
  leadDistributor,
  customButton,
}) => {
  return (
    <>
        <PersistentDrawerLeft
          props={props}
          title={title}
          path={path}
          leadManger={leadManger}
          project={project}
          task={task}
          resources={resources}
          callLogs={callLogs}
          faq={faq}
          apiData={apiData}
          leadDistributor={leadDistributor}
          api={api}
          news={news}
          customButton={customButton}
        />
    </>
  );
};

export default AnalyticsSideNav;
