import React, {
  FunctionComponent,
  useEffect,
  useState,
} from "react";
import styles from "./Navbar.module.css";
import Logo from "../../Assets/Images/head.svg";
import LogoNew from "../../Assets/Images/ify_logo_new.png";
import classNames from "classnames";
import { AiOutlineArrowRight } from "react-icons/ai";
import { FaUserCircle } from "react-icons/fa";
import UserDetails from "../UserDetails/UserDetails";
import { connect } from "react-redux";
import ProfileImageModal from "../Modals/ProfileImageModal/ProfileImageModal";

type props = {
  props?: any;
  title:
  | "Organizations"
  | "Contacts"
  | "Users"
  | "Drilldown";
  path: string;
  leadManger: Boolean;
  project?: string;
  task?: string;
  resources?: string;
  callLogs?: string;
  faq?: string;
  user: any;
  api?: string;
  news?: string;
  apiData?: string;
  leadDistributor?: string;
  customButton?: string;
};

const Navbar: FunctionComponent<props> = ({
  props,
  title,
  path,
  leadManger,
  project,
  task,
  resources,
  callLogs,
  faq,
  user,
  api,
  news,
  apiData,
  leadDistributor,
  customButton,
}) => {
  const [showUserDetail, setShowUserDetails] =
    useState(false);
  const [expand, setExpand] = useState(false);
  const [profileModal, setProfileModal] = useState(false);
  useEffect(() => {
    let timeOut: any;
    if (showUserDetail === true) {
      setExpand(true);
      document.body.style.overflowX = "hidden";
      timeOut = setTimeout(() => {
        document.body.style.overflowX = "auto";
      }, 300);
    }
    return () => clearTimeout(timeOut);
  }, [showUserDetail]);
  useEffect(() => {
    let timeOut: any;
    if (expand === false) {
      document.body.style.overflowX = "hidden";
      timeOut = setTimeout(() => {
        setShowUserDetails(false);
        document.body.style.overflowX = "auto";
      }, 300);
    }
    return () => clearTimeout(timeOut);
  }, [expand]);

  const toggleUserDetails = () => {
    if (showUserDetail === false) {
      setShowUserDetails(true);
    } else {
      setExpand(false);
    }
  };
  return (
    <div className={styles.navbar}>
      <img
        className={styles.logo}
        src={LogoNew}
        alt={"logo"}
      />
      {title !== "Drilldown" && (
        <>
          <p className={styles.text}>
            Profile
            <AiOutlineArrowRight
              size={18}
              style={{ marginLeft: "5px" }}
            />
          </p>
          <div className={styles.line} />
          <div className={styles.logOutView}>
            {user.user_image && user.user_image !== "" ? (
              <img
                alt="userImage"
                src={user.user_image}
                className={styles.image}
                onClick={toggleUserDetails}
              />
            ) : (
              <FaUserCircle
                color="#C0C0C0"
                size={25}
                onClick={toggleUserDetails}
              />
            )}
            {showUserDetail && (
              <div
                className={
                  expand
                    ? styles.userDetailExpand
                    : styles.userDetailClosed
                }
              >
                <UserDetails
                  showUserDetail={showUserDetail}
                  close={toggleUserDetails}
                  openModal={(data) =>
                    setProfileModal(data)
                  }
                />
              </div>
            )}
          </div>{" "}
        </>
      )}
      {profileModal && (
        <ProfileImageModal
          open={profileModal}
          close={() => setProfileModal(false)}
        />
      )}
    </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
  };
};

export default connect(mapStateToProps)(Navbar);
