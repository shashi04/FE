import React, { FunctionComponent, useState, useEffect } from "react";
import styles from "../../CommonStyles/CommonGraphStyles.module.css";

type props = {
  data: any;
  type: "not_int_reason" | "lost_reason";
  heading: string;
  usersList: any;
};

const DoughnutTable: FunctionComponent<props> = ({
  data,
  heading,
  type,
  usersList,
}) => {
  const [tableData, setTableData] = useState<any[]>([]);
  const [header, setHeader] = useState<any[]>([]);
  useEffect(() => {
    const tempHeader: string[] = ["User Name"];
    const tempData: any[] = [];
    Object.keys(data).forEach((key) => {
      const analytics = data[key].leadAnalytics[type];
      Object.keys(analytics).forEach((key) => {
        if (!tempHeader.includes(key)) {
          tempHeader.push(key);
        }
      });
      tempData.push({ name: usersList[key], ...analytics });
    });
    console.log(tempHeader, tempData);
    setHeader(tempHeader);
    setTableData(tempData);
  }, [data]);

  return (
    <div className={styles.detailsBox}>
      <p className={styles.graphHeading}>{heading}</p>
      <div className={styles.typeBox}>
        {header.map((item, index) => (
          <p key={index} className={styles.text} style={{ minWidth: "140px" }}>
            {item}
          </p>
        ))}
      </div>
      {tableData.map((item, index) => (
        <>
          <div className={styles.typeBox}>
            <p
              key={index}
              className={styles.text}
              style={{ minWidth: "140px" }}
            >
              {item.name}
            </p>
            {header.slice(1).map((key: string, sIndex) => (
              <p
                key={String(index) + String(sIndex)}
                className={styles.text}
                style={{ minWidth: "140px" }}
              >
                {item[key] ? item[key] : 0}
              </p>
            ))}
          </div>
        </>
      ))}
    </div>
  );
};

export default DoughnutTable;
