import React, { FunctionComponent } from "react";
import ReactLoading from "react-loading";
import styles from "./Loading.module.css";
import Logo from "../../Assets/Images/head.svg";
import LogoNew from "../../Assets/Images/ify_logo_new.png";
import { connect } from "react-redux";

type props = {
  logo?: boolean;
  progress: any;
};

const Loading: FunctionComponent<props> = ({ logo, progress }) => {
  return (
    <div className={styles.parent} style={{ backgroundColor: "#00000020",width:"100vw",marginTop:"70px" }}>
    <ReactLoading
        type={"spinningBubbles"}
        color={"#279f9f"}
        height={90}
        width={90}
        className={styles.loader}
      />
      {logo && (
        <img
          src={LogoNew}
          alt={"Logo"}
          style={{ position: "fixed", bottom: 50 }}
        />
      )}
      {progress.total !== 0 && (
        <p
          style={{
            marginTop: "60px",
            color: "#2FA2D3",
            fontSize: "24px",
            fontWeight: 600,
          }}
        >
          {progress.completed} / {progress.total} Completed
        </p>
      )}
    </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    progress: state.progress,
  };
};

export default connect(mapStateToProps)(Loading);
