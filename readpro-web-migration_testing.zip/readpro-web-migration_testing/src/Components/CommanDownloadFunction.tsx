import { sortAnalytics, sortAnalyticsDownLoadReport } from "../Values/utils";

export const DownloadReportCsv = (reportData: any, reportHeader: any, usersList: any, findValue: any) => {
  let data: any[] = [];
  let gt: { [key: string]: any } = {};
  const dataArray = reportData?.map((val: any) => {
    return { ...val, name: val.owner = usersList[val.owner] };
  })
  dataArray?.map((item: any) => {
    let filterData = reportHeader.map((li: any) => {
      if (findValue === 'stage') {
        let valueItem = item.stage.filter((i: any) => i.stage === li)[0]?.count ? item.stage.filter((i: any) => i.stage === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'budget') {
        let valueItem = item.budget.filter((i: any) => i.budget === li)[0]?.count ? item.budget.filter((i: any) => i.budget === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'location') {
        let valueItem = item.location.filter((i: any) => i.location === li)[0]?.count ? item.location.filter((i: any) => i.location === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'project') {
        let valueItem = item.project.filter((i: any) => i.project === li)[0]?.count ? item.project.filter((i: any) => i.project === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'property_stage') {
        let valueItem = item.property_stage.filter((i: any) => i.property_stage === li)[0]?.count ? item.property_stage.filter((i: any) => i.property_stage === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'property_type') {
        let valueItem = item.property_type.filter((i: any) => i.property_type === li)[0]?.count ? item.property_type.filter((i: any) => i.property_type === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'lost_reason') {
        let valueItem = item.lost_reason.filter((i: any) => i.lost_reason === li)[0]?.count ? item.lost_reason.filter((i: any) => i.lost_reason === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'not_int_reason') {
        let valueItem = item.not_int_reason.filter((i: any) => i.not_int_reason === li)[0]?.count ? item.not_int_reason.filter((i: any) => i.not_int_reason === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
      else if (findValue === 'type') {
        let valueItem = item.type.filter((i: any) => i.type === li)[0]?.count ? item.type.filter((i: any) => i.type === li)[0]?.count : 0;
        return { key: li, value: valueItem }
      }
    })
    var object = filterData.reduce(
      (obj: any, item: any) => Object.assign(obj, { [item.key]: item.value }), {});
    return (
      data.push({ name: item.name, total: item.total, ...object })
    )
  })
  data.forEach((item) => {
    Object.keys(item).forEach((key) => {
      if (key !== 'name') {
        if (gt[key]) {
          gt[key] += item[key];
        }
        else {
          gt[key] = item[key];
        }
      }
    });
  });
  data.sort(sortAnalyticsDownLoadReport);
  data.unshift({ name: 'Grand Total', ...gt });

  return data;
}