const filterSortReducer = (
  state = {},
  action: {
    type: "SET_FILTER_SORT";
    payload: any;
  }
) => {
  switch (action.type) {
    case "SET_FILTER_SORT":
      return { ...action.payload };

    default:
      return state;
  }
};

export default filterSortReducer;
