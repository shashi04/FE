const refreshReducer = (
  state = {
    refreshContacts: false,
    refreshTasks: false,
    refreshCallLogs: false,
  },
  action: {
    type:
      | "SET_REFRESH_CONTACTS"
      | "SET_REFRESH_TASKS"
      | "SET_REFRESH_CALL_LOGS";
    payload: boolean;
  }
) => {
  switch (action.type) {
    case "SET_REFRESH_CONTACTS":
      return { ...state, refreshContacts: action.payload };

    case "SET_REFRESH_TASKS":
      return { ...state, refreshTasks: action.payload };

    case "SET_REFRESH_CALL_LOGS":
      return { ...state, refreshCallLogs: action.payload };

    case "SET_REFRESH_TASKS":
      return { ...state, refreshTasks: action.payload };

    case "SET_REFRESH_CALL_LOGS":
      return { ...state, refreshCallLogs: action.payload };

    default:
      return state;
  }
};

export default refreshReducer;
