const filterObjectReducer = (
  state = {},
  action: {
    type: "SET_OBJECT";
    payload: any;
  }
) => {
  switch (action.type) {
    case "SET_OBJECT":
      return { ...state, ...action.payload };

    default:
      return state;
  }
};

export default filterObjectReducer;
