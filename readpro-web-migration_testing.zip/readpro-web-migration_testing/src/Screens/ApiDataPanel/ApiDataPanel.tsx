import React, { useState, useEffect, FunctionComponent } from "react";
import Topbar from "../../Components/TopBar/TopBar";
import commonStyle from "../common.module.css";
import { connect, useDispatch } from "react-redux";
import { APIDATA_COLUMNS } from "../../Values/tables";

import { filterStatus, searchAPIItem } from "../../Values/utils";
import moment from "moment";
import { getDateString, searchContacts } from "../../Values/utils";
import CustomTable from "../../Components/CustomTable/CustomTable";

import ApiModal from "../../Components/Modals/ApiModal/ApiModal";
import { fetchApiData, fetchApiFilterData } from "../../Services/organizations";
import NewImportProjectModal from "../../Components/Modals/ImportModal/NewImportProjectModal";
import ApiTopBar from "../../Components/TopBar/ApiTopBar";
import NewImportApiModal from "../../Components/Modals/ImportModal/NewImportApiModal";
import ApiCustomTable from "../../Components/CustomTable/ApiCustomTable";
import styles from '../Analytics/Analytics.module.css';


type props = {
  history: any;
  organizationId: any;
  user: any;
};

const ApiDataPanel: FunctionComponent<props> = ({
  history,
  organizationId,
  user,
}) => {
  const dispatcher = useDispatch();
  const [searchQuery, setsearchQuery] = useState("");
  const [columnModal, setColumnModal] = useState(false);
  const [filterData, setFilterData] = useState<any[] | undefined>(undefined);
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [selectedRowsData, setSelectedRowsData] = useState<any[]>([]);
  const [apiModal, setApiModal] = useState(false);
  const [API, setAPI] = useState<any[] | undefined>(undefined);
  const [status, setStatus] = useState("ALL");
  const [temporaryData, setTemporaryData] = useState<any[]>([]);
  const [apiFilter, setApiFilter] = useState("7");
  const [showImportModal, setShowImportModal] = useState(false);
  const [searchedItem, setsearchedItem] = useState("");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [totalCounts, setTotalCounts] = useState<any>();
  const [lastPage, setLastPage] = useState(-1);

  useEffect(() => {
    if (user.organization_id) {
      if (apiFilter === "7") {
        let prevDate = moment().subtract(7, "day").toDate();
        let currentDate = moment().toDate();
        fetchApiFilterData(
          user.organization_id,
          (val) => setAPI(val),
          prevDate,
          currentDate
        );
      } else if (apiFilter === "30") {
        let prevDate = moment().subtract(30, "day").toDate();
        let currentDate = moment().toDate();
        fetchApiFilterData(
          user.organization_id,
          (val) => setAPI(val),
          prevDate,
          currentDate
        );
      } else {
        fetchApiData(user.organization_id, (val) => setAPI(val));
      }
    }
  }, [user, apiFilter]);

  useEffect(() => {
    if (API) {
      let data: any[] = [];
      API.forEach((item) => {
        data.push(item);
      });
      setFilterData(data);
    }
  }, [API]);

  useEffect(() => {
    if (status === "ALL") {
      if (API) {
        const data = searchAPIItem(API, searchQuery);
        setTemporaryData(data);
        setFilterData(data);
      }
    } else {
      const data = searchAPIItem(temporaryData, searchQuery);
      setFilterData(data);
    }
    // eslint-disable-next-line
  }, [searchQuery, API]);

  useEffect(() => {
    if (searchQuery === "") {
      if (API) {
        const data = filterStatus(API, status);
        setTemporaryData(data);
        setFilterData(data);
      }
    } else {
      const data = filterStatus(temporaryData, status);
      setFilterData(data);
    }
    // eslint-disable-next-line
  }, [status, API]);

  let isFinished = false;
  const exportFile = () => {
    let data: any[] = [];
    if (selectedRowsData.length !== 0) {
      selectedRowsData.forEach((item) => {
        data.push({
          "budget": item.budget,
          "created_by": item.created_by,
          "property_stage": item.property_stage,
          "location": item.location,
          "customer_name": item.customer_name,
          "contact_no": item.contact_no,
          "alternate_no": item.alternate_no,
          "country_code": item.country_code,
          "associate_contact": item.associate_contact,
          "email": item.email,
          "campaign": item.campaign,
          "add_set": item.add_set,
          "contact_owner_email": item.contact_owner_email,
          "status": item.status,
          "created_at": getDateString(item.created_at),
          "lead_assign_time": item.lead_assign_time,
          "lead_id": item.lead_id,
          "property_type": item.property_type,
          "stage": item.stage,
          "fail_reason": item.fail_reason,
          "project": item.project,
          "lead_source": item.lead_source,
        });
      });
    }
    return data;
  };
  return (
    <>
     <div className={styles.parent} style={{ display: "block", marginTop: "0px",backgroundColor:"white"}}>
     
      <div className={commonStyle.topBar} style={{ marginTop: "0px", backgroundColor: "white" }}> 
        <Topbar
          history={history}
          title={"Add Api Data"}
          path={"/addUsers"}
          onChange={(val) => setsearchQuery(val)}
          filterText="Status"
          setColumnModal={(data) => setColumnModal(data)}
          showStatusBox={true}
          setApiModal={(data) => setApiModal(data)}
          setStatus={(status) => setStatus(status)}
          status={status}
          setApiFilter={(data) => setApiFilter(data)}
          apiFilterData={apiFilter}
          onClick={() => {
            setShowImportModal(true);
          }}
          show={true}
          onExport={exportFile}
        />
      </div>
      <div className={commonStyle.parent} style={{minHeight:"450px"}}>
        <CustomTable
          tableColumns={APIDATA_COLUMNS}
          tableRows={filterData}
          selectedRows={selectedRows}
          setSelectedRows={(data) => setSelectedRows(data)}
          tableType="API"
          showColumnModal={columnModal}
          hideColumnModal={() => setColumnModal(false)}
          selectedRowsData={selectedRowsData}
          setSelectedRowsData={(data) => setSelectedRowsData(data)}
          setSearchedItem={(val) => setsearchQuery(val)}
        />
      </div>
      {showImportModal && (
        <NewImportApiModal
          open={showImportModal}
          close={() => setShowImportModal(false)}
          organization_id={user.organization_id}
          history={history}
          usersList={organizationId}
          user={user}
        />
      )}
      {apiModal === true && (
        <ApiModal open={apiModal} close={() => setApiModal(false)} />
      )}
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    organizationId: state.organization.id,
    organizationUsers: state.organizationUsers.data,
    user: state.user.data,
  };
};
export default connect(mapStateToProps)(ApiDataPanel);
