import React from "react";

const AddTasks = () => {
  return (
    <div>
      <p>Add Tasks</p>
    </div>
  );
};

export default AddTasks;
