import React, { useMemo, useState, useEffect } from "react";
import styles from "./ProjectsPanel.module.css";
import commonStyle from "../common.module.css";
import Topbar from "../../Components/TopBar/TopBar";
import { PROJECT_COLUMNS } from "../../Values/tables";
import { useTable, useSortBy, useFilters, useColumnOrder } from "react-table";
import TableHeader from "../../Components/TableHeader/TableHeader";
import { deleteProject, fetchProjects } from "../../Services/contacts";
import ImportContactsModal from "../../Components/Modals/ImportModal/ImportContactsModal";
import { connect, useDispatch } from "react-redux";
import {
  getFilterObject,
  filterProjectStatus,
  searchProjectItem,
} from "../../Values/utils";
import Loading from "../../Components/Loading/Loading";
import ColumnManagerModal from "../../Components/Modals/ColumnManagerModal/ColumnManager";

import { MdDelete } from "react-icons/md";
import { FiEdit3 } from "react-icons/fi";
import ApiTopBar from "../../Components/TopBar/ApiTopBar";
import ApiCustomTable from "../../Components/CustomTable/ApiCustomTable";
import ImportProjectModal from "../../Components/Modals/ImportModal/ImportProjectModal";
import NewImportProjectModal from "../../Components/Modals/ImportModal/NewImportProjectModal";
import DeleteSelectedModal from "../../Components/Modals/DeleteSelectedModal/DeleteSelectedModal";
import DeleteProjectSelectedModal from "../../Components/Modals/DeleteSelectedModal/DeleteProjectSelectedModal";



const Project = ({ history, user, organizationUsers }: any) => {
  const dispatcher = useDispatch();
  const [projectsList, setProjectsList] = useState<any[] | undefined>(
    undefined
  );
  const [tasksImportModal, setTasksImportModal] = useState(false);
  const [notesImportModal, setNotesImportModal] = useState(false);
  const [callLogsImportModal, setCallLogsImportModal] = useState(false);
  const [lastPage, setLastPage] = useState(-1);
  const [totalCounts, setTotalCounts] = useState<any>();
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [searchedItem, setsearchedItem] = useState("");
  const [selectedRowsData, setSelectedRowsData] = useState<any[]>([]);
  const [filterData, setFilterData] = useState<any[] | undefined>(undefined);
  const [temporaryData, setTemporaryData] = useState<any[]>([]);
  const [searchQuery, setsearchQuery] = useState("");
  const [status, setStatus] = useState("ALL");
  const [columnModal, setColumnModal] = useState(false);
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [showImportModal, setShowImportModal] = useState(false);
  const [load, setLoad] = useState(false);
  const [owner, setOwner] = useState(false);
  const [deletePopup, setDeletePopop] = useState(false);


  useEffect(() => {
    if (user.organization_id) {
      const unsub = fetchProjects(
        (data) => setProjectsList(data),
        user.organization_id
      );
      return () => {
        unsub();

      };
    }
  }, [user]);

  useEffect(() => {
    if (projectsList !== undefined) {
      setFilterData(projectsList);
    }
  }, [projectsList, dispatcher]);
  useEffect(() => {
    if (status === "ALL") {
      if (projectsList) {
        const data = searchProjectItem(projectsList, searchQuery);
        setTemporaryData(data);
        setFilterData(data);
      }
    } else {
      const data = searchProjectItem(temporaryData, searchQuery);
      setFilterData(data);
    }
    // eslint-disable-next-line
  }, [searchQuery, projectsList]);

  useEffect(() => {
    if (searchQuery === "") {
      if (projectsList) {
        const data = filterProjectStatus(projectsList, status);
        setTemporaryData(data);
        setFilterData(data);
        setTotalCounts(data.length);
      }
    } else {
      const data = filterProjectStatus(temporaryData, status);
      setFilterData(data);
    }
    // eslint-disable-next-line
  }, [status, projectsList]);

  useEffect(() => {
    if (selectedRows.length > 0) {
      setOwner(true);
    } else if (selectedRows.length === 0) {
      setOwner(false);
    }
  }, [selectedRows]);

  const selectAll = (checked: boolean) => {
    if (checked === true) {
      setSelectedRows(Array.from(Array(filterData?.length).keys()));
    } else {
      setSelectedRows([]);
    }
  };

  const columns = useMemo(() => PROJECT_COLUMNS, []);
  const data = useMemo(() => (filterData ? filterData : []), [filterData]);

  const tableInstance: any = useTable(
    {
      columns,
      data,
    },
    useFilters,
    useSortBy,
    useColumnOrder
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    allColumns,
    setColumnOrder,
    toggleHideAllColumns,

    //@ts-ignore
    setAllFilters,
  } = tableInstance;


  const setColumns = (columnList: any) => {
    setColumnOrder(columnList);
  };

  useEffect(() => {
    if (filterData) {
      getFilterObject(filterData, dispatcher);
    }
  }, [filterData, dispatcher]);

  const clearSort = () => {
    headerGroups[0].headers.forEach((header: any) => {
      header.clearSortBy();
    });
  };
  const clearSelectedRowsData = () => {
    setSelectedRowsData([]);
    setSelectedRows([]);
  };
  let isFinished = false;

  const exportFile = () => {
    let data: any[] = [];
    if (selectedRowsData.length !== 0) {
      selectedRowsData.forEach((item) => {
        data.push({
          Name: item.project_name,
          "Developer Name": item.developer_name,
          "Address": item.address,
          "Rera Link": item.rera_link,
          "Walkthrough Link": item.walkthrough_link,
          "Property Type": item.property_type,
          Status: item.status,
          "Created By": item.created_by,
          Profile: item.profile,
          "Project Id": item.project_id,
          "Project image": item.project_image,

        });
      });
    }
    return data;
  };

  return (
    <>
     <div className={styles.parent} style={{display:"block",marginTop:"0px",backgroundColor:"white"}}>
      {load === true && <Loading />}
      <div className={commonStyle.topBar} style={{marginTop:"0px",backgroundColor:"white"}}>
      <ApiTopBar
          history={history}
          title={"Add Project"}
          path={"/addProjects"}
          owner={owner}
          deleteSelected={() => {
            setDeletePopop(true);
          }}
          onClick={() => {
            setShowImportModal(true);
          }}
          onChange={(val) => setsearchedItem(val)}
          filterText={"Status"}
          setColumnModal={(data) => setColumnModal(data)}
          show={true}
          showStatusBox={true}
          onExport={exportFile}
          onCallLogsImport={() => {
            setCallLogsImportModal(true);
          }}
          onNotesImport={() => {
            setNotesImportModal(true);
          }}
          onTasksImport={() => {
            setTasksImportModal(true);
          }}
        />
      </div>
      <div className={commonStyle.parent} style={{minHeight:"450px",height:"100%"}}>
        <ApiCustomTable
          tableColumns={PROJECT_COLUMNS}
          tableRows={filterData}
          selectedRows={selectedRows}
          setSelectedRows={(data) => setSelectedRows(data)}
          tableType="Project"
          showColumnModal={columnModal}
          hideColumnModal={() => setColumnModal(false)}
          selectedRowsData={selectedRowsData}
          setSelectedRowsData={(data) => setSelectedRowsData(data)}
          setPage={(val) => setPage(val)}
          setPageSize={(val) => setPageSize(val)}
          pageSize={pageSize}
          page={page}
          isFinished={isFinished}
          totalCount={totalCounts}
          lastPage={lastPage}
        />
      </div>
      {showImportModal && (
        <NewImportProjectModal
          open={showImportModal}
          close={() => setShowImportModal(false)}
          organization_id={user.organization_id}
          history={history}
          usersList={organizationUsers}
          user={user}
        />
      )}

      {deletePopup && (
        <DeleteProjectSelectedModal
          data={selectedRowsData}
          clearSelectedRowsData={clearSelectedRowsData}
          open={deletePopup}
          totalData={data}
          organization_id={user.organization_id}
          close={() => {
            setDeletePopop(false);
          }}
        />
      )}
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
    organizationUsers: state.organizationUsers.data,
  };
};

export default connect(mapStateToProps)(Project);
