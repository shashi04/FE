import React, { FunctionComponent, useEffect, useRef } from "react";
import { useState } from "react";
import Loading from "../../Components/Loading/Loading";
import styles from "../AddContacts/AddContacts.module.css";
import { AiOutlineClose } from "react-icons/ai";
import { connect, useDispatch } from "react-redux";
import { showSnackbarAction } from "../../Redux/actions";
import { updateFAQ } from "../../Services/resources";
import { useLocation } from "react-router-dom";

type props = {
  history: any;
  user: any;
  propsData: any
};
const EditFAQ: FunctionComponent<props> = ({ history, user, propsData }) => {
  const location = useLocation();
  const [load, setLoad] = useState(false);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const[faqId,setFaqId]=useState("");
  const [allData,setAllData]=useState<any[]>([]);
  const dispatcher = useDispatch();
  const questionRef: any = useRef();
  const answerRef: any = useRef();

  useEffect(() => {
    if (location.state) {
      const data: any = location?.state;
      setAllData(data.allData)
      setFaqId(data.item.id);
      setQuestion(data.item.question);
      setAnswer(data.item.answer);
    }
  }, [location]);

  const handleCheck = () => {
    if (questionRef.current.value === "") {
      dispatcher(showSnackbarAction("Please Enter Question!!", "error"));
      return false;
    } else if (answerRef.current.value === "") {
      dispatcher(showSnackbarAction("Please Enter Answer!!", "error"));
      return false;
    } else {
      return true;
    }
  };

  const update = () => {
    let filterDataArr:Array<Object> = [];
    const val = handleCheck();
    if (val) {
      const filterData=allData?.filter((list:any)=>list.id!=faqId)
      filterDataArr.push({"answer":answer,"id":faqId,"question":question},...filterData)
      setLoad(true);
      updateFAQ(
        user.organization_id,
        filterDataArr,
        dispatcher,
        (data: boolean) => setLoad(data),
        history,
      );
    }
  };

  return (
    <div className={styles.parent}>
      {load === true && <Loading />}
      <div className={styles.child}>
        <div className={styles.headerView}>
          <p className={styles.heading}> Edit FAQ</p>
          <AiOutlineClose
            className={styles.closeIcon}
            size={25}
            onClick={() => history.replace("/faq")}
          />
        </div>
        <div className={styles.title}>
          <p className={styles.one}>Question</p>
          <p className={styles.two}>*</p>
        </div>
        <div className={styles.box}>
          <textarea
            style={{ width: "100%", resize: "none", marginTop: "17px" }}
            rows={4}
            cols={10}
            placeholder={"Enter Question"}
            ref={questionRef}
            onChange={(e) => setQuestion(e.target.value)}
            value={question}
          ></textarea>
        </div>

        <div style={{ marginTop: "22px" }} className={styles.title}>
          <p className={styles.one}>Answer</p>
          <p className={styles.two}>*</p>
        </div>
        <div className={styles.box}>
          <textarea
            style={{ width: "100%", resize: "none", marginTop: "17px" }}
            rows={6}
            cols={10}
            placeholder={"Enter Answer"}
            ref={answerRef}
            onChange={(e) => setAnswer(e.target.value)}
            value={answer}
          ></textarea>
        </div>
        <button className={styles.button} onClick={() =>update()}>
          Submit
        </button>
      </div>
    </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
  };
};

export default connect(mapStateToProps)(EditFAQ);
