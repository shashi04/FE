import React, { FunctionComponent } from 'react';
import { useEffect, useState } from 'react';
import { connect, useDispatch } from 'react-redux';

import { fetchCallLogs, fetchUserCallLogs } from '../../Services/contacts';

import TopBar from '../../Components/TopBar/TopBar';
import commonStyle from '../common.module.css';
import Loading from '../../Components/Loading/Loading';
import {
  booleanObject,
  CALLLOG_COLUMNS,
  datesField,
} from '../../Values/tables';
import { getDateString, searchCallLogs } from '../../Values/utils';
import CustomTable from '../../Components/CustomTable/CustomTable';
import axios from 'axios';
import moment from 'moment';
import {
  setFilterObject,
  setRefreshCallLogs,
  showSnackbarAction,
} from '../../Redux/actions';
import ApiCustomTable from '../../Components/CustomTable/ApiCustomTable';
import ApiTopBar from '../../Components/TopBar/ApiTopBar';
import { url } from '../../Values/constants';
import styles from '../Analytics/Analytics.module.css';

type props = {
  user: any;
  contacts: any;
  history: any;
  role: any;
  organizationUsers: any;
  teamLeadUsers: any;
  filterObject: any;
  filterSort: any;
  refreshCallLogs: boolean;
  searchString: string;
};

let isFinished = false;

const CallLogsPanel: FunctionComponent<props> = ({
  user,
  contacts,
  history,
  role,
  organizationUsers,
  teamLeadUsers,
  filterObject,
  searchString,
  filterSort,
  refreshCallLogs,
}) => {
  const [filterData, setFilterData] = useState<any[] | undefined>(undefined);
  const [callList, setCallList] = useState<any[]>();
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [selectedRowsData, setSelectedRowsData] = useState<any[]>([]);
  const [searchedItem, setsearchedItem] = useState('');
  const [columnModal, setColumnModal] = useState(false);
  const [originalData, setOriginalData] = useState<any[] | undefined>(
    undefined
  );
  const [contactsMap, setcontactsMap] = useState<any>(undefined);

  const [lastPage, setLastPage] = useState(-1);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [load, setLoad] = useState(false);
  const [allCallLogs, setAllCallLogs] = useState(false);
  const [totalCounts, setTotalCounts] = useState<any>();
  const [userMap, setUserMap] = useState<any>({});
  const [filterCount, setFilterCount] = useState<any>({});
  const [showImportModal, setShowImportModal] = useState(false);

  const dispatcher = useDispatch();

  const callApi = async (
    paginate?: boolean,
    localPageSize?: Number,
    localPage?: Number
  ) => {
    if (isFinished === true) {
      return;
    } else {
      setLoad(true);
      const filters: { [key: string]: any[] } = {};
      let feild;
      filters["transfer_status"] = [false];
      Object.keys(filterObject).forEach((item) => {
        if (filterObject && filterObject[item].length > 0) {
          if (item === "is_button_called" || item === "transfer_status" || item === "associate_status" || item === "source_status") {
            if (filterObject[item].length === 2) {
              filters[item] = [true, false];
            } else {
              filters[item] =
                filterObject[item][0] === "True" ? [true] : [false];
            }
          } else {
            if (item === "contact_no") {
            } else filters[item] = filterObject[item];
          }
        }
      });

      if (searchString === '') {
        feild = 'contact_no';
      } else {
        if (searchString.match(/^[0-9]+$/) != null) {
          feild = 'contact_no';
        } else {
          feild = 'customer_name';
        }
      }
      let records = localPageSize ? localPageSize : pageSize;
      const apiData = {
        uid: user.uid,
        page: localPage ? localPage : page + 1,
        searchString: searchString,
        sort:
          Object.keys(filterSort).length === 0
            ? { created_at: '-1' }
            : filterSort,
        pageSize: localPageSize ? localPageSize : pageSize,
        filter: filters,
      };
      setFilterCount(filters);
      console.log('Api Data - ', apiData);
      try {
        axios.defaults.headers.common['x-access-token'] =
          'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA';
        const res = await axios.post(url + '/callLogs/search', apiData);
        console.log('data:', res);
        let data: any[] = res.data;
        if (data.length < records && paginate) {
          isFinished = true;
          setLastPage(page);
        }

        data.forEach((task) => {
          task.contactId = task.leadId;
          task.reporting_to = userMap[task.contact_owner_email];
          delete task['Id'];
          Object.keys(task).forEach((key) => {
            if (datesField.includes(key) && task[key] !== '') {
              if (task[key] !== null) {
                task[key] = moment(task[key]);
              } else {
                task[key] = '';
              }
            }
          });
        });
        console.log(data);
        if (paginate && filterData) {
          let newData = [...filterData, ...data];
          setFilterData(newData);
        } else {
          setFilterData(data);
        }
        setLoad(false);
      } catch {
        setFilterData([]);
        setLoad(false);
        dispatcher(showSnackbarAction('Please Try Again!!', 'error'));
      }
    }
  };

  useEffect(() => {
    if (user === undefined || user.uid === undefined) {
      setFilterData([]);
      return;
    }
    if (userMap === undefined) {
      setFilterData([]);
      return;
    }
    isFinished = false;
    setLastPage(-1);
    if (page !== 0) {
      setPage(0);
    }
    callApi(false, pageSize, 1);
  }, [user, filterObject, filterSort, searchString, allCallLogs]);

  useEffect(() => {
    if (
      filterData &&
      filterData.length <= (page + 1) * pageSize &&
      isFinished === false
    ) {
      if (page === 0) {
        callApi(false, pageSize);
      } else {
        callApi(true, pageSize);
      }
    }
  }, [page, pageSize]);

  useEffect(() => {
    if (user === undefined || user.uid === undefined) {
      setFilterData([]);
      return;
    }
    callCountApi();
  }, [refreshCallLogs, user.uid, filterCount]);

  const callCountApi = async () => {
    axios.defaults.headers.common['x-access-token'] =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA';
    const res = await axios.post(url + '/callLogs/callLogCount', {
      uid: user.uid,
      leadFilter: filterCount
    });
    setTotalCounts(res.data.total);
  };



  useEffect(() => {
    if (refreshCallLogs === true) {
      callApi();
      getCallLogsFilter();
      dispatcher(setRefreshCallLogs(false));
    }
  }, [refreshCallLogs]);

  const getCallLogsFilter = async () => {
    axios.defaults.headers.common['x-access-token'] =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA';
    const res = await axios.post(url + '/callLogs/filterValues', {
      uid: user.uid,
    });

    console.log(res.data);

    console.log('Filter data:', res.data[0]);
    if (res.data[0]) {
      dispatcher(setFilterObject({ ...res.data[0], ...booleanObject }));
    } else {
      dispatcher(setFilterObject({}));
    }
  };

  useEffect(() => {
    if (user === undefined || user.uid === undefined) {
      return;
    }
    getCallLogsFilter();
  }, [user]);

  const exportFile = () => {
    let data: any[] = [];
    if (selectedRowsData.length === 0) {
    } else {
      selectedRowsData.forEach((item) => {
        data.push({
          'Lead Id': item.leadId,
          'Customer Name': item.customer_name,
          Owner: item.contact_owner_email,
          Stage: item.stage,
          Project: item.project,
          Location: item.location,
          Budget: item.budget,
          'Contact No': item.contact_no,
          'Inventory Type': item.inventory_type,
          Source: item.source,
          'Transfer Status': item.transfer_status,
          Status: item.status,
          'Created By': item.created_by,
          Duration: item.duration,
          'Created Date and Time': getDateString(item.created_at),
        });
      });
    }

    return data;
  };

  return (
    <>
      <div className={styles.parent} style={{ display: "block", marginTop: "0px", backgroundColor: "white" }}>
      {filterData === undefined && <Loading />}
        <div className={commonStyle.topBar} style={{ marginTop: "0px", backgroundColor: "white" }}>
          <ApiTopBar
            history={history}
            title={'Add Call Logs'}
            path={'/addContacts'}
            onClick={() => {
              setShowImportModal(true);
            }}
            onChange={(val) => setsearchedItem(val)}
            filterText={'Status'}
            setColumnModal={(data) => setColumnModal(data)}
            show={true}
            showStatusBox={true}
            searchedString={searchString}
            onExport={exportFile}
          />
        </div>
        <div className={commonStyle.parent} style={{ minHeight: "450px" }}>
        
          <ApiCustomTable
            tableColumns={CALLLOG_COLUMNS}
            tableRows={filterData}
            selectedRows={selectedRows}
            setSelectedRows={(data) => setSelectedRows(data)}
            tableType="CallLogs"
            showColumnModal={columnModal}
            hideColumnModal={() => setColumnModal(false)}
            selectedRowsData={selectedRowsData}
            setSelectedRowsData={(data) => setSelectedRowsData(data)}
            setPage={(val) => setPage(val)}
            setPageSize={(val) => setPageSize(val)}
            callApi={callApi}
            pageSize={pageSize}
            page={page}
            isFinished={isFinished}
            totalCount={totalCounts}
            lastPage={lastPage}
          />
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
    role: state.user.role,
    contacts: state.contacts,
    organizationUsers: state.organizationUsers.data,
    teamLeadUsers: state.teamLeadUsers.data,
    filterObject: state.filter,
    filterSort: state.filterSort,
    searchString: state.searchItem.callLogsSearchString,
    refreshCallLogs: state.refresh.refreshCallLogs,
  };
};
export default connect(mapStateToProps)(CallLogsPanel);
