import React, { FunctionComponent, useState } from "react";
import { useEffect } from "react";
import { connect, useDispatch } from "react-redux";
import Loading from "../../Components/Loading/Loading";
import { fetchFAQ } from "../../Services/resources";
import { deleteFAQ } from "../../Services/resources";
import styles from "./FAQPanel.module.css";

type props = { history: any; user: any };
const FAQPanel: FunctionComponent<props> = ({ history, user }) => {
  const [faqList, setfaqList] = useState<any[] | undefined>(undefined);
  const dispatcher = useDispatch();

  useEffect(() => {
    if (user.organization_id) {
      fetchFAQ(user.organization_id, (data) => setfaqList(data));
    }
  }, [user]);

  const handleDelete = (deleteData:any) => {
     let faqId=deleteData;
     const filterData=faqList?.filter((list:any)=>list.id!=faqId?.id)
     deleteFAQ(
        user.organization_id,
        filterData,
        dispatcher,
        history,
      );
  }
  return (
    <div className={styles.parent}>
      {faqList === undefined && <Loading />}
      <div className={styles.child}>
        <div className={styles.topBar}>
          <p className={styles.title}>FAQ Section</p>
          <button
            className={styles.addButton}
            onClick={() => history.push("/addFAQ")}
          >
            Add FAQ
          </button>
        </div>
        <div className={styles.subChild}>
          {faqList?.map((item, index) => (
            <div className={styles.FAQContainer} key={index}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end"
                }}>
                <div style={{ padding: "5px" }}><button
                  style={{
                    cursor: "pointer",
                    backgroundColor: "red",
                    border: "red",
                    color: "white",
                    width: "80px",
                    height: "30px",
                    borderRadius: "5px",
                    fontFamily: "sans-serif",
                    boxSizing: "border-box"
                  }} type="button"
                  onClick={() => {
                    const confirmBox = window.confirm(
                      "Please Confirm, do you want to Delete the Selected FAQ?"
                    )
                    if (confirmBox === true) {
                      handleDelete(item)
                    }
                  }}>
                  Delete</button></div>
                <div style={{ padding: "5px" }}><button
                  style={{
                    cursor: "pointer",
                    backgroundColor: "#6495ED",
                    border: "red",
                    color: "white",
                    width: "80px",
                    height: "30px",
                    borderRadius: "5px",
                    fontFamily: "sans-serif",
                    boxSizing: "border-box"
                  }} type="button"
                  onClick={() => history.push({
                    pathname: '/editFAQ',
                    state:{"allData":faqList,"item":item}
                  })}
                >Edit</button></div>
              </div>
              <p className={styles.heading}>{`Question ${index + 1}`}</p>
              <div className={styles.container}>
                {item.question}</div>
              <div className={styles.line}></div>
              <p className={styles.heading}>{`Answer ${index + 1}`}</p>
              <div className={styles.container}>{item.answer}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
  };
};

export default connect(mapStateToProps)(FAQPanel);
