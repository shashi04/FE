import React, { useRef, useState } from "react";
import styles from "./ForgotPassword.module.css";
import Logo from "../../Assets/Images/readPro_logo.png";
import Logo2 from "../../Assets/Images/ify_logo.png";
import LogoNew from "../../Assets/Images/ify_logo_new.png";
import TextInput from "../../Components/TextInput/TextInput";
import { MdEmail } from "react-icons/md";
import background from "../../Assets/Images/passwordBackground.svg";
import { auth } from "../../Firebase";
import { emailValidate } from "../../Values/validatorsnew";
import { useDispatch } from "react-redux";
import { showSnackbarAction } from "../../Redux/actions";
import Loading from "../../Components/Loading/Loading";
import landingBackground from "../../Assets/Images/landing_background.svg";
import NewBackground from "../../Assets/Images/new_background.jpg";
import LatestBackground from "../../Assets/Images/signin_background_latest.svg";
import AppStore from "../../Assets/Images/appstore.svg";
import LogoOld from "../../Assets/Images/head.svg";
import PlayStore from "../../Assets/Images/playstore.svg";

const ForgotPassword = (props: any) => {

  const emailRef: any = useRef();
  const dispatcher = useDispatch();
  const [load, setLoad] = useState(false);

  const send = async (email: string) => {
    console.log(email);
    if (email !== "") {
      try {
        if (email) {
          setLoad(true);
          await auth.sendPasswordResetEmail(email);
          setLoad(false);
          dispatcher(
            showSnackbarAction(
              "Password reset information have been sent on you registered email id",
              "success"
            )
          );
          props.history.push("/");
        }
      } catch (error) {
        console.log("reset error", error);
      }
    } else {
      dispatcher(showSnackbarAction("Please Enter Your Email!", "error"));
    }
  };
  return (
    <div
      className={styles.container}
    >
      <img src={LogoNew} alt="logo" className={styles.logo} />
      <div style={{ display: "flex", height: "80vh" }}>
        <div className={styles.box1}>
          <img
            src={LatestBackground}
            alt=""
            width="100%"
            height="100%"
          // className={styles.logo}
          />
        </div>
        <div className={styles.box2}>
          <div className={styles.form}>
            <div className={styles.header}>
              <h4 style={{ fontFamily: "Poppins", fontWeight: 600, fontSize: "24px" }}>Forgot Password?</h4>
              <p className={styles.headerText} style={{ fontSize: "14px", marginTop: "20px" }}>
                Enter your registered email below to receive password reset
                instructions
              </p>
            </div>
            <div className={styles.inputs}>
              <TextInput title={"Email"} ref={emailRef} validator={emailValidate}>
                <MdEmail color={"#053535"} />
              </TextInput>
            </div>
            <div className={styles.buttons}>
              <button
                className={styles.button}
                onClick={() => send(emailRef.current?.value)}
              >
                Send
              </button>
              <div
                className={styles.forgetBox}
                onClick={() => props.history.push("/")}
              >
                <p style={{ marginBottom: "20px", marginTop: "10px", fontSize: "14px" }}>Remember Password?</p>
                <p className={styles.loginText} style={{ marginBottom: "20px", marginTop: "10px", fontSize: "14px" }}>Login</p>
              </div>
            </div>
            <div className={styles.storeIcons}>
              <div className={styles.iconContainer1}>
                <a href="https://play.google.com/store/apps/details?id=com.readpro" target="_blank">
                  <img
                    src={PlayStore}
                    alt={"logo"}
                    width={"25px"}
                  />
                </a>
              </div>
              <div className={styles.iconContainer2}>
                <a href="https://apps.apple.com/in/app/read-pro/id1566457452" target="_blank">
                  <img
                    src={AppStore}
                    alt={"logo"}
                    width={"40px"}
                  />
                </a>
              </div>
            </div>

            <p style={{ textAlign: "center", marginTop: "24px", fontSize: "14px" }}>Powered by</p>
            <div className={styles.socialIcons}>
              <img
                src={Logo2}
                alt={"logo"}
                height={"35px"}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
