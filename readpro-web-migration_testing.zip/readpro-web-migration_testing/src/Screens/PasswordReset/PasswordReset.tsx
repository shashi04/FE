import React, { FunctionComponent, useEffect, useRef, useState } from "react";
import styles from "./PasswordReset.module.css";
import Logo from "../../Assets/Images/readPro_logo.png";
import background from "../../Assets/Images/background.svg";
import PasswordInput from "../../Components/Password/PasswordInput";
import { RiLockPasswordFill } from "react-icons/ri";

import qs from "qs";

import Logo2 from "../../Assets/Images/ify_logo.png";
import { connect, useDispatch } from "react-redux";

import Loading from "../../Components/Loading/Loading";
import { resetPassword } from "../../Services/auth";
import { passwordValidate } from "../../Values/validatorsnew";

type props = {
  history: any;
  firstLogin: boolean;
};

let oobCode: any;

const PasswordReset: FunctionComponent<props> = ({ history, firstLogin }) => {
  const confirmPasswordRef: any = useRef();
  const passwordRef: any = useRef();
  const dispatcher = useDispatch();
  const [reset, setReset] = useState(false);
  const [load, setLoad] = useState(false);

  const Reset = async (password: string, confirmPassword: string) => {
    resetPassword(
      password,
      confirmPassword,
      dispatcher,
      oobCode,
      (value) => setLoad(value),
      (val) => setReset(val),
      firstLogin,
      history
    );
  };

  useEffect(() => {
    const data = qs.parse(history.location.search, { ignoreQueryPrefix: true });
    if (data.oobCode === undefined) {
      if (firstLogin !== true) {
        history.push("/");
      }
    }

    oobCode = data.oobCode;
  }, [history, firstLogin]);
  return (
    <div
      style={{
        backgroundImage: `url(${background})`,
        backgroundRepeat: "no-repeat",
        width: "100%",
        backgroundSize: "contain",
        backgroundPositionY: "85px",
        backgroundColor: "rgba(0, 0, 0, 0.02)",
      }}
      className={styles.parent}
    >
      {load === true && <Loading />}
      <div className={styles.container}>
        <div className={styles.logoContainer}>
          <img
            src={Logo}
            alt={"top"}
            className={styles.image}
            width={"150vw"}
          />
          <p className={styles.welcome}>Welcome,</p>
          <p className={styles.text}>Reset Password for your Your Account.</p>
        </div>
        {reset === true ? (
          <>
            <p className={styles.completeText}>Password Reset Successfully</p>
          </>
        ) : (
          <div className={styles.inputContainer}>
            <div className={styles.form}>
              <div className={styles.input}>
                <PasswordInput
                  title={"Password"}
                  ref={passwordRef}
                  validator={passwordValidate}
                >
                  <RiLockPasswordFill color={"#808080"} />
                </PasswordInput>
              </div>

              <div className={styles.input}>
                <PasswordInput
                  title={"Confirm Password"}
                  ref={confirmPasswordRef}
                  validator={passwordValidate}
                  onPress={() =>
                    Reset(
                      passwordRef.current?.value,
                      confirmPasswordRef.current?.value
                    )
                  }
                >
                  <RiLockPasswordFill color={"#808080"} />
                </PasswordInput>
              </div>
            </div>
            <div className={styles.buttonView}>
              <button
                className={styles.button}
                onClick={() =>
                  Reset(
                    passwordRef.current?.value,
                    confirmPasswordRef.current?.value
                  )
                }
              >
                Reset
              </button>
            </div>
          </div>
        )}

        <div className={styles.bottomView}>
          <p className={styles.bottomText}>POWERED BY</p>
          <img src={Logo2} alt={"bottom "} width={"150vw"} />
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = (state: any) => {
  return {
    firstLogin: state.user.firstLogin,
  };
};

export default connect(mapStateToProps)(PasswordReset);
