import React, {
  FunctionComponent,
  useEffect,
  useState,
} from "react";
import TopBar from "../../Components/TopBar/TopBar";
import commonStyle from "../common.module.css";

import CustomTable from "../../Components/CustomTable/CustomTable";
import { getDataFromRoute } from "../../Services/contacts";
import { connect, useDispatch } from "react-redux";
import {
  setClearFilter,
  showSnackbarAction,
  setFilterObject,
  setRefreshContacts,
} from "../../Redux/actions";
import axios from "axios";

import moment from "moment";

import { url } from "../../Values/constants";
import {
  CONTACT_COLUMNS,
  datesField,
  booleanObject,
} from "../../Values/tables";
import Firebase from "firebase/app";
import ApiTopBar from "../../Components/TopBar/ApiTopBar";
import ApiCustomTable from "../../Components/CustomTable/ApiCustomTable";

type props = {
  history: any;
  user: any;
  searchString: string;
  filterSort: any;
  filterObject: any;
  role: string;
  organizationUsers: any[];
  refreshContacts: any;
};
let usersList: any[] = [];
let isFinished = false;
const ApiDrilldownPanel: FunctionComponent<props> = ({
  history,
  user,
  searchString,
  filterSort,
  filterObject,
  role,
  organizationUsers,
  refreshContacts,
}) => {
  const [searchedItem, setsearchedItem] = useState("");
  const [columnModal, setColumnModal] = useState(false);
  const [filterData, setFilterData] = useState<
    any[] | undefined
  >(undefined);
  const [selectedRows, setSelectedRows] = useState<any[]>(
    []
  );
  const [selectedRowsData, setSelectedRowsData] = useState<
    any[]
  >([]);

  const [lastPage, setLastPage] = useState(-1);
  const [allContacts, setAllContacts] = useState<
    any[] | undefined
  >(undefined);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [load, setLoad] = useState(false);
  const [allLeads, setAllLeads] = useState(false);
  const [totalCounts, setTotalCounts] = useState<any>();
  const [userMap, setUserMap] = useState<any>(undefined);
  const dispatcher = useDispatch();
  const createUsersList = (
    email: string,
    users: any[],
    uid: boolean
  ) => {
    users.map((item: any) => {
      if (usersList.includes(item)) {
        return;
      } else {
        if (
          item.reporting_to === email &&
          item.status === "ACTIVE"
        ) {
          if (!usersList.includes(item)) {
            usersList.push(item);
          }

          createUsersList(item.user_email, users, uid);
        }
      }
    });
  };

  useEffect(() => {
    var key: any;
    for (var i = 0; i < localStorage.length; i++) {
      key = localStorage.key(i);

      if (key !== "columns" && key !== "drilldownData") {
        localStorage.removeItem(key);
      }
    }
    dispatcher(setClearFilter(true));
    const savedData = localStorage.getItem("drilldownData");
    if (savedData) {
      console.log("data:", savedData);
    }
  }, []);

  const callApi = async (
    paginate?: boolean,
    localPageSize?: Number,
    localPage?: Number
  ) => {
    if (isFinished === true) {
      return;
    } else {
      setLoad(true);
      const filters: { [key: string]: any[] } = {};
      let feild;
      if (!allLeads) {
        filters["transfer_status"] = [false];
      }
      if (searchString === "") {
        feild = "contact_no";
      } else {
        if (searchString.match(/^[0-9]+$/) != null) {
          feild = "contact_no";
        } else {
          feild = "customer_name";
        }
      }
      let records = localPageSize
        ? localPageSize
        : pageSize;
      const apiData = {
        uid: user.uid,
        page: localPage ? localPage : page + 1,
        searchString: searchString,
        sort:
          Object.keys(filterSort).length === 0
            ? { created_at: "-1" }
            : filterSort,
        pageSize: localPageSize ? localPageSize : pageSize,
        filter: filters,
      };
      try {
        axios.defaults.headers.common["x-access-token"] =
          "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA";
        const res = await axios.post(
          url + "/leads/search",
          apiData
        );
        let data: any[] = res.data;
        if (data.length < records) {
          isFinished = true;
          setLastPage(page);
        }

        data.forEach((lead) => {
          lead.contactId = lead.Id;
          lead.reporting_to =
            userMap[lead.contact_owner_email];
          delete lead["Id"];
          Object.keys(lead).forEach((key) => {
            if (
              datesField.includes(key) &&
              lead[key] !== ""
            ) {
              if (lead[key] !== null) {
                lead[key] =
                  Firebase.firestore.Timestamp.fromDate(
                    moment(lead[key]).toDate()
                  );
              } else {
                lead[key] = "";
              }
            }
          });
        });
        if (paginate && filterData) {
          let newData = [...filterData, ...data];
          setFilterData(newData);
        } else {
          setFilterData(data);
        }
        setLoad(false);
      } catch {
        setFilterData([]);
        setLoad(false);

        dispatcher(
          showSnackbarAction("Please Try Again!!", "error")
        );
      }
    }
  };

  useEffect(() => {
    if (user === undefined || user.uid === undefined) {
      setFilterData([]);
      return;
    }
    if (userMap === undefined) {
      setFilterData([]);
      return;
    }
    isFinished = false;
    setLastPage(-1);
    if (page !== 0) {
      setPage(0);
    }
    callApi(false, pageSize, 1);
  }, [
    user,
    filterObject,
    filterSort,
    searchString,
    allLeads,
    userMap,
  ]);

  useEffect(() => {
    if (
      filterData &&
      filterData.length <= (page + 1) * pageSize &&
      isFinished === false
    ) {
      if (page === 0) {
        callApi(false, pageSize);
      } else {
        callApi(true, pageSize);
      }
    }
  }, [page, pageSize]);

  const callCountApi = async () => {
    axios.defaults.headers.common["x-access-token"] =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA";
    const res = await axios.post(url + "/leads/leadCount", {
      uid: user.uid,
    });

    setTotalCounts(res.data.total);
  };

  useEffect(() => {
    if (user === undefined || user.uid === undefined) {
      setFilterData([]);
      return;
    }
    callCountApi();
  }, [refreshContacts, user.uid]);

  useEffect(() => {
    if (refreshContacts === true) {
      callApi();
      getContactsFilter();
      dispatcher(setRefreshContacts(false));
    }
  }, [refreshContacts]);

  const getContactsFilter = async () => {
    axios.defaults.headers.common["x-access-token"] =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA";
    const res = await axios.post(
      url + "/leads/filterValues",
      {
        uid: user.uid,
      }
    );
    if (res.data[0]) {
      dispatcher(
        setFilterObject({
          ...res.data[0],
          ...booleanObject,
        })
      );
    } else {
      dispatcher(setFilterObject({}));
    }
  };

  useEffect(() => {
    if (user === undefined || user.uid === undefined) {
      return;
    }
    getContactsFilter();
  }, [user]);

  const setUsersList = () => {
    if (role === "Lead Manager") {
      organizationUsers.map((item: any) => {
        if (usersList.includes(item)) {
          return;
        } else {
          if (item.status === "ACTIVE") {
            usersList.push(item);
          }
        }
      });
    } else {
      createUsersList(
        user.user_email,
        organizationUsers,
        false
      );
    }
  };
  return (
    <>
      <div className={commonStyle.topBar}>
        <ApiTopBar
          history={history}
          title={"Add Contacts"}
          path={"/addContacts"}
          changeOwner={() => {
            setUsersList();
          }}
          onChange={(val) => setsearchedItem(val)}
          filterText={"Status"}
          setColumnModal={(data) => setColumnModal(data)}
          show={true}
          showStatusBox={true}
          searchedString={searchString}
          setAllLeads={(data) => setAllLeads(data)}
        />
      </div>

      <div className={commonStyle.parent}>
        <ApiCustomTable
          tableColumns={CONTACT_COLUMNS}
          tableRows={filterData}
          selectedRows={selectedRows}
          setSelectedRows={(data) => setSelectedRows(data)}
          tableType="User"
          showColumnModal={columnModal}
          hideColumnModal={() => setColumnModal(false)}
          selectedRowsData={selectedRowsData}
          setSelectedRowsData={(data) =>
            setSelectedRowsData(data)
          }
          setPage={(val) => setPage(val)}
          setPageSize={(val) => setPageSize(val)}
          callApi={callApi}
          pageSize={pageSize}
          page={page}
          isFinished={isFinished}
          totalCount={totalCounts}
          lastPage={lastPage}
        />
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
    role: state.user.role,
    filterSort: state.filterSort,
    refreshContacts: state.refresh.refreshContacts,
    searchString: state.searchItem.searchString,
    filterObject: state.filter,
    organizationUsers: state.organizationUsers.data,
  };
};
export default connect(mapStateToProps)(ApiDrilldownPanel);
