
import React, { FunctionComponent, useEffect, useState } from 'react';
import TopBar from '../../Components/TopBar/TopBar';
import commonStyle from '../common.module.css';

import CustomTable from '../../Components/CustomTable/CustomTable';
import { getDataFromRoute } from '../../Services/contacts';
import { connect, useDispatch } from 'react-redux';
import {
  setClearFilter,
  showSnackbarAction,
  setFilterObject,
  setRefreshContacts,
} from '../../Redux/actions';
import axios from 'axios';
import Cookies from 'universal-cookie';
import moment from 'moment';

import { url } from '../../Values/constants';
import {
  CONTACT_COLUMNS,
  datesField,
  booleanObject,
} from '../../Values/tables';
import Firebase from 'firebase/app';
import ApiTopBar from '../../Components/TopBar/ApiTopBar';
import ApiCustomTable from '../../Components/CustomTable/ApiCustomTable';
import Loading from '../../Components/Loading/Loading';
import { fetchOrganizationsUsers } from "../../Services/users";

type props = {
  history: any;
  user: any;
  searchString: string;
  filterSort: any;
  filterObject: any;
  role: string;
  organizationUsers: any[];
  refreshContacts: any;
  organizationId: string;
};
let usersList: any[] = [];
let isFinished = false;
const ApiDrilldownPanel: FunctionComponent<props> = ({
  history,
  user,
  searchString,
  filterSort,
  filterObject,
  role,
  organizationUsers,
  refreshContacts,
  organizationId
}) => {
  const [searchedItem, setsearchedItem] = useState('');
  const [columnModal, setColumnModal] = useState(false);
  const [filterData, setFilterData] = useState<any[] | undefined>(undefined);
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const [selectedRowsData, setSelectedRowsData] = useState<any[]>([]);

  const [lastPage, setLastPage] = useState(-1);
  const [allContacts, setAllContacts] = useState<any[] | undefined>(undefined);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [load, setLoad] = useState(false);
  const [allLeads, setAllLeads] = useState(false);
  const [totalCounts, setTotalCounts] = useState<any>();
  const [userMap, setUserMap] = useState<any>(undefined);
  const [drillDownCount, SetDrillDownCount] = useState<any>({});
  const [localStorageData, setLocalStorageData] = useState<any>({});
  const [uid, setuid] = useState<any>({});
  const [filterApiCount, SetFilterApiCount] = useState<any>({});
  const [drillRole, setDrillRole] = useState<any>({});
  const [associate, setassociate] = useState<any>({});
  const [userBranchMap, setBranchMap] = useState<any>(undefined);
  const [userTeamMap, setTeamMap] = useState<any>(undefined);
  const dispatcher = useDispatch();
  const cookies = new Cookies();
  
  let userId=cookies.get("uId");
  console.log("organizationUse",organizationUsers)
  const createUsersList = (email: string, users: any[], uid: boolean) => {
    users.map((item: any) => {
      if (usersList.includes(item)) {
        return;
      } else {
        if (item.reporting_to === email && item.status === 'ACTIVE') {
          if (!usersList.includes(item)) {
            usersList.push(item);
          }

          createUsersList(item.user_email, users, uid);
        }
      }
    });
  };

  useEffect(() => {
    if (localStorageData.organizationid) {
      const unSub = fetchOrganizationsUsers(
        dispatcher,
        localStorageData.organizationid
      );
      return () => {
        unSub();
      };
    }
  }, [localStorageData,dispatcher]);

  useEffect(() => {
    if (organizationUsers) {
      let uids: { [key: string]: string } = {};
      let uidsBranch: { [key: string]: string } = {};
      let uidsTeam: { [key: string]: string } = {};
      organizationUsers.forEach((user: any) => {
        uids[user.user_email] = user.reporting_to;
        uidsBranch[user.user_email] = user.branch;
        uidsTeam[user.user_email] = user.team;
      });
      setBranchMap(uidsBranch)
      setUserMap(uids);
      setTeamMap(uidsTeam)
    }
  }, [organizationUsers]);
  useEffect(() => {
    var key: any;
    for (var i = 0; i < localStorage.length; i++) {
      key = localStorage.key(i);

      if (key !== 'columns' && key !== 'drilldownData') {
        localStorage.removeItem(key);
      }
    }
    dispatcher(setClearFilter(true));
    const savedData = localStorage.getItem('drilldownData');
    if (savedData) {
      setLocalStorageData(JSON.parse(savedData));
    }
  }, []);

  const callApi = async (
    paginate?: boolean,
    localPageSize?: Number,
    localPage?: Number
  ) => {
    if (isFinished === true) {
      return;
    }
    else {
      setLoad(true);
      const filters: { [key: string]: any[] } = { ...localStorageData.leadFilter };
     
      if (localStorageData.source === true) {
        filters['source_status'] = ['True'];
      }
      else {
        filters['associate_status'] = ['True'];
      }
      setDrillRole(localStorageData.role);
      let feild;
     
      Object.keys(filterObject).forEach((item) => {
        if (filterObject && filterObject[item].length > 0) {
          filters[item] = filterObject[item];
        }
      });
      if (searchString === '') {
        feild = 'contact_no';
      } else {
        if (searchString.match(/^[0-9]+$/) != null) {
          feild = 'contact_no';
        } else {
          feild = 'customer_name';
        }
      }
      const { reporting_to, team, branch, ...objLeadUserFilterValues } = filters;
      let records = localPageSize ? localPageSize : pageSize;
      const apiData = {
        uid: localStorageData.source === true && localStorageData.role===false ? userId : localStorageData.uid,
        organizationid: localStorageData.organizationid,
        page: localPage ? localPage : page + 1,
        searchString: searchString,
        sort:
          Object.keys(filterSort).length === 0
            ? { created_at: '-1' }
            : filterSort,
        pageSize: localPageSize ? localPageSize : pageSize,
        taskFilter: localStorageData.taskFilter,
        leadUserFilter: {
          reporting_to,
          team,
          branch
        },
        leadFilter: localStorageData.source === true && localStorageData.role === false ? { ...objLeadUserFilterValues, "lead_source": [localStorageData.uid] } : objLeadUserFilterValues,
        role: localStorageData.source === true && localStorageData.role === false ? true : localStorageData.role,

      };
      SetDrillDownCount(filters);
      SetFilterApiCount(apiData)
      try {
        axios.defaults.headers.common['x-access-token'] =
          'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA';
        const res = await axios.post(url + '/leads/drillDownSearch', apiData);
        let data: any[] = res.data;
        if (data.length < records) {
          isFinished = true;
          setLastPage(page);
        }
        data.forEach((lead) => {
          lead.contactId = lead.Id;
          lead["reporting_to"] = userMap[lead.contact_owner_email];
          lead["branch"] = userBranchMap[lead.contact_owner_email];
          lead["team"] = userTeamMap[lead.contact_owner_email];
          delete lead['Id'];
          Object.keys(lead).forEach((key) => {
            if (datesField.includes(key) && lead[key] !== '') {
              if (lead[key] !== null) {
                lead[key] = Firebase.firestore.Timestamp.fromDate(
                  moment(lead[key]).toDate()
                );
              } else {
                lead[key] = '';
              }
            }
          });
        });
        if (paginate && filterData) {
          let newData = [...filterData, ...data];
          setFilterData(newData);
        } else {
          setFilterData(data);
        }
        setLoad(false);
      } catch (error) {
        setFilterData([]);
        setLoad(false);
        dispatcher(showSnackbarAction('Please Try Again!!', 'error'));
      }
    }
  };
  useEffect(() => {
    if (localStorageData.uid === undefined) {
      setFilterData([]);
      return;
    }
    if (userMap === undefined) {
      setFilterData([]);
      return;
    }
    isFinished = false;
    setLastPage(-1);
    if (page !== 0) {
      setPage(0);
    }
    callApi(false, pageSize, 1);
  }, [allLeads, filterObject,userMap, localStorageData]);

  useEffect(() => {
    if (
      filterData &&
      filterData.length <= (page + 1) * pageSize &&
      isFinished === false
    ) {
      if (page === 0) {
        callApi(false, pageSize);
      } else {
        callApi(true, pageSize);
      }
    }
  }, [page, pageSize]);
  useEffect(() => {
    if (localStorageData.uid === undefined) {
      setFilterData([]);
      return;
    }
    callCountApi();
  }, [refreshContacts, localStorageData.uid, drillDownCount, filterApiCount]);

  const callCountApi = async () => {
    const filterValues: { [key: string]: any[] } = {};
    Object.keys(drillDownCount).forEach((item) => {
      if (drillDownCount && drillDownCount[item].length > 0) {
        if (item === "is_button_called" || item === "transfer_status" || item === "associate_status" || item === "source_status") {
          if (drillDownCount[item].length === 2) {
            filterValues[item] = [true, false];
          } else {
            filterValues[item] =
              drillDownCount[item][0] === "True" ? [true] : [false];
          }
        }
        else filterValues[item] = drillDownCount[item];
      }
    });
    const { reporting_to, team, branch, ...objLeadFilterDrillDownCount } = filterValues;
    axios.defaults.headers.common['x-access-token'] =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA';
    if (drillRole === true) {
      const res = await axios.post(url + '/leads/contacttotalcount', {
        uid: localStorageData.uid,
        leadUserFilter: {
          reporting_to,
          team,
          branch
        },
        leadFilter: objLeadFilterDrillDownCount,
        taskFilter: localStorageData.taskFilter
      });
      setTotalCounts(res.data.total);
    }
    else {
      const uId = localStorageData.uid
      const res = await axios.post(url + '/leads/contacttotalcount', {
        uid: localStorageData.source === true && localStorageData.role===false ?userId :uId,
        leadUserFilter: {
          reporting_to,
          team,
          branch
        },
        leadFilter:localStorageData.source === true && localStorageData.role===false ?{ ...objLeadFilterDrillDownCount, "lead_source": [uId] } :{ ...objLeadFilterDrillDownCount, "uid": [uId] },
        taskFilter: localStorageData.taskFilter
      });
      setTotalCounts(res.data.total);
    }
  };

  useEffect(() => {
    if (refreshContacts === true) {
      callApi();
      getContactsFilter();
      dispatcher(setRefreshContacts(false));
    }
  }, [refreshContacts]);

  const getContactsFilter = async () => {
    const uId = localStorageData.uid
    axios.defaults.headers.common['x-access-token'] =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibGFrc2hheSIsImlhdCI6MTYyOTczOTgzMX0.E0mqgfrDj5su4grI1r8PH973srqJy3k2AG_hvCx-EaA';
    const res = await axios.post(url + '/leads/filterValues', {
      uid:localStorageData.source === true && localStorageData.role===false ?userId :uId
    });

    if (res.data[0]) {
      dispatcher(setFilterObject({ ...res.data[0], ...booleanObject }));
    } else {
      dispatcher(setFilterObject({}));
    }
  };

  useEffect(() => {
    if (localStorageData.uid === undefined) {
      return;
    }
    getContactsFilter();
  }, [localStorageData.uid]);

  const setUsersList = () => {
    if (role === 'Lead Manager') {
      organizationUsers.map((item: any) => {
        if (usersList.includes(item)) {
          return;
        } else {
          if (item.status === 'ACTIVE') {
            usersList.push(item);
          }
        }
      });
    } else {
      createUsersList(user.user_email, organizationUsers, false);
    }
  };
  return (
    <>
      <div className={commonStyle.topBar}>
        <ApiTopBar
          history={history}
          title={'Add Contacts'}
          path={'/addContacts'}
          changeOwner={() => {
            setUsersList();
          }}
          onChange={(val) => setsearchedItem(val)}
          filterText={'Status'}
          setColumnModal={(data) => setColumnModal(data)}
          show={true}
          showStatusBox={true}
          searchedString={searchString}
          setAllLeads={(data) => setAllLeads(data)}
        />
      </div>

      <div className={commonStyle.parent} style={{height:"81%"}}>
        {load === true && <Loading />}
        <ApiCustomTable
          tableColumns={CONTACT_COLUMNS}
          tableRows={filterData}
          selectedRows={selectedRows}
          setSelectedRows={(data) => setSelectedRows(data)}
          tableType="User"
          showColumnModal={columnModal}
          hideColumnModal={() => setColumnModal(false)}
          selectedRowsData={selectedRowsData}
          setSelectedRowsData={(data) => setSelectedRowsData(data)}
          setPage={(val) => setPage(val)}
          setPageSize={(val) => setPageSize(val)}
          callApi={callApi}
          pageSize={pageSize}
          page={page}
          isFinished={isFinished}
          totalCount={totalCounts}
          lastPage={lastPage}
        />
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => {
  return {
    user: state.user.data,
    role: state.user.role,
    filterSort: state.filterSort,
    refreshContacts: state.refresh.refreshContacts,
    searchString: state.searchItem.contactsSearchString,
    filterObject: state.filter,
    organizationUsers: state.organizationUsers.data,
    organizationId: state.organization.id,
  };
};
export default connect(mapStateToProps)(ApiDrilldownPanel);
